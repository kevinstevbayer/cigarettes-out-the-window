# compile(love) - an animated ASCII short film

A procedural, multi-chapter ASCII story built from scratch in Python + Pygame:
sun-faded 70s VHS, lo-fi bedroom-pop colours, late-night terminal energy.
About 4 minutes, ending on an interactive question.

## Run it

```bash
pip install -r requirements.txt
python main.py
```

Python 3.10+ and pygame 2.5+. Everything is procedural, and the fonts it needs are
bundled in `fonts/`, so it looks the same on every machine (including Tamil, Hindi,
Arabic, Hebrew, Thai, etc. in the "I love you in every language" chapter).
Windows: double-click `run_windows.bat`. Mac/Linux: `./run.sh`.

## Controls

| Key | Action |
|---|---|
| SPACE | Pause / resume |
| RIGHT / LEFT | Next / previous chapter |
| R | Restart chapter (from the epilogue: restart the whole film) |
| F11 | Fullscreen |
| Y / Enter or click | Say yes in Chapter 8 (the N button runs away) |
| ESC | Quit |

## Make it yours

Open `story.py`. Everything marked `<<< REAL MEMORY >>>` is a placeholder - replace it with
what really happened (first messages, the late-night chat, the commit history, your own
letter). All narration, captions and the final question live there; no engine code needs touching.
`config.py` holds pacing, resolution and the CRT/VHS effect toggles.

## Layout

```
main.py  config.py  story.py
engine/        renderer, effects (CRT/VHS), particles, noise, text, scenes
ascii_assets/  flame, vinyl, moon, heart, phone, eyes, figures, scenery, phrases
scenes/        ch00_prologue ... ch09_epilogue
fonts/         bundled fonts (DejaVu, Noto - see NOTO-OFL.txt)
```

Fonts: DejaVu (free licence) and Noto Sans (SIL Open Font License, `fonts/NOTO-OFL.txt`).
Song titles appear only as tiny on-screen easter eggs; no lyrics are used.
