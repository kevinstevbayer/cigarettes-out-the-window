"""CH5 EVERY LANGUAGE: 'translate(love)' — 34 'I love you' phrases assembling into a heart."""

import math
from typing import List, Tuple
import pygame

from ascii_assets.objects import draw_heart_field
from ascii_assets.phrases import LOVE_PHRASES, display_form
from engine.easing import clamp, lerp, pulse_heartbeat, smoothstep
from engine.palette import (
    CREAM,
    DUSTY_ROSE,
    FADED_TEAL,
    HOT_ROSE,
    LAVENDER_HAZE,
    MINT_GLOW,
    RGB,
    SUNSET_ORANGE,
    WARM_AMBER,
)
from engine.renderer import AsciiRenderer
from engine.scene import Scene

# Phrases that are code rather than a human language are shown as terminal captions instead
CODE_LANGS = ("Python", "Binary")

HEART_CX: float = 60.0
HEART_CY: float = 17.0
OUTER_SCALE: Tuple[float, float] = (1.72, 0.80)   # (x cells per unit, y cells per unit)
INNER_SCALE: Tuple[float, float] = (1.02, 0.47)


def _heart_point(theta: float, scale: Tuple[float, float]) -> Tuple[float, float]:
    """Point on the classic parametric heart, centred on (HEART_CX, HEART_CY) in grid cells."""
    hx = 16.0 * pow(math.sin(theta), 3.0)
    hy = -(
        13.0 * math.cos(theta)
        - 5.0 * math.cos(2.0 * theta)
        - 2.0 * math.cos(3.0 * theta)
        - math.cos(4.0 * theta)
    )
    # hy spans roughly -12 .. +17, so its vertical midpoint is ~2.5
    return HEART_CX + hx * scale[0], HEART_CY + (hy - 2.5) * scale[1]


class _PhraseNode:
    """One 'I love you' that drifts in, locks onto the heart outline, bursts, and re-forms."""

    def __init__(
        self,
        index: int,
        slot: int,
        ring_count: int,
        outer: bool,
        lang: str,
        native: str,
        color: RGB,
    ) -> None:
        self.lang: str = lang
        self.label: str = display_form(lang, native)
        self.color: RGB = color
        self.outer: bool = outer
        self.index: int = index

        theta = (slot + (0.0 if outer else 0.5)) / float(ring_count) * math.tau
        scale = OUTER_SCALE if outer else INNER_SCALE
        self.heart_x, self.heart_y = _heart_point(theta, scale)

        # Drift in from far outside the heart, in the direction of its own angle
        self.start_x: float = HEART_CX + math.cos(theta + 0.6) * 72.0
        self.start_y: float = HEART_CY + math.sin(theta + 0.6) * 30.0

        # Burst target: explode outward from the centre
        dx = self.heart_x - HEART_CX
        dy = self.heart_y - HEART_CY
        self.burst_x: float = HEART_CX + dx * 1.45 + math.cos(theta) * 6.0
        self.burst_y: float = HEART_CY + dy * 1.35 + math.sin(theta) * 3.0


class Ch05EveryLanguageScene(Scene):
    """Multilingual 'I love you' phrases drift in, form a pulsing heart, burst, and re-form."""

    def __init__(self) -> None:
        super().__init__(5)
        palette = [DUSTY_ROSE, WARM_AMBER, FADED_TEAL, CREAM, SUNSET_ORANGE, LAVENDER_HAZE, HOT_ROSE]
        human = [p for p in LOVE_PHRASES if p[0] not in CODE_LANGS]
        ring_count = (len(human) + 1) // 2
        self.nodes: List[_PhraseNode] = []
        for i, (lang, native, _roman) in enumerate(human):
            outer = i % 2 == 0
            self.nodes.append(
                _PhraseNode(i, i // 2, ring_count, outer, lang, native, palette[i % len(palette)])
            )
        self.code_captions: List[Tuple[str, str]] = [
            (f"{p[1]}", f"// {p[2]}") for p in LOVE_PHRASES if p[0] in CODE_LANGS
        ]

    def draw(self, renderer: AsciiRenderer, surface: pygame.Surface) -> None:
        # Phase timeline:
        # 0..8s: drift inward from the edges to the heart outline
        # 8..15s: pulse together as a glowing heart, phrases take turns lighting up
        # 15..19s: burst outward like a supernova
        # 19..26s: re-assemble around the pulsing core
        t = self.time
        heart_strength = smoothstep(5.5, 9.5, t)
        burst_t = math.sin(((t - 15.0) / 4.0) * math.pi) if 15.0 <= t <= 19.0 else 0.0

        if heart_strength > 0.1:
            draw_heart_field(
                renderer,
                cx=int(HEART_CX),
                cy=int(HEART_CY),
                scale=1.15 * (1.0 - 0.3 * burst_t) * (0.4 + 0.6 * heart_strength),
                t=t,
                pulse_bpm=76.0,
            )

        beat = 1.0 + 0.06 * pulse_heartbeat(t, bpm=76.0)
        assemble_t = smoothstep(0.5, 8.0, t)
        total = len(self.nodes)

        # Faint continuous outline so the heart shape reads even between phrases
        if heart_strength > 0.05 and burst_t < 0.5:
            outline_glow = 0.25 * heart_strength * (1.0 - 2.0 * burst_t)
            for k in range(150):
                theta = k / 150.0 * math.tau
                ox, oy = _heart_point(theta, OUTER_SCALE)
                ox = HEART_CX + (ox - HEART_CX) * beat
                oy = HEART_CY + (oy - HEART_CY) * beat
                renderer.set_cell(int(round(ox)), int(round(oy)), ".", DUSTY_ROSE, glow=outline_glow)

        labels: List[Tuple[float, float, _PhraseNode, float]] = []
        for node in self.nodes:
            hx = HEART_CX + (node.heart_x - HEART_CX) * beat
            hy = HEART_CY + (node.heart_y - HEART_CY) * beat
            x = lerp(node.start_x, hx, assemble_t)
            y = lerp(node.start_y, hy, assemble_t)
            if burst_t > 0.0:
                x = lerp(x, node.burst_x, burst_t)
                y = lerp(y, node.burst_y, burst_t)

            renderer.set_cell(
                int(round(x)),
                int(round(y)),
                "♥" if node.index % 3 == 0 else "*",
                node.color,
                glow=0.6,
            )

            # Spotlight: each phrase takes a turn. Phases are strided so neighbours on the
            # outline never light up together, which keeps the text readable.
            phase = (t / 3.4 + ((node.index * 11) % total) / float(total)) % 1.0
            window = 0.30
            if assemble_t > 0.55 and phase < window:
                fade = math.sin(math.pi * phase / window)
                labels.append((x, y, node, fade))

        # Code-flavoured phrases live under the heart as terminal captions
        if t > 9.0:
            reveal = smoothstep(9.0, 11.0, t)
            for i, (code, comment) in enumerate(self.code_captions):
                row = 30 + i
                renderer.draw_centered_text(row, f"{code}   {comment}", FADED_TEAL, glow=0.45 * reveal)

        self.narrator.draw_narration_panel(renderer)
        renderer.render_to_surface(surface)

        # Crisp multilingual Unicode text, drawn on the pixel surface over the glowing heart
        for x, y, node, fade in labels:
            width = renderer.unicode_text_width(node.label)
            px = x * renderer.cell_w
            if node.outer:
                # keep outer labels outside the outline: right-align on the left half, left-align on the right
                px = px - width - 10 if x < HEART_CX else px + 10
            else:
                px = px - width / 2.0
            py = y * renderer.cell_h - 2
            renderer.draw_unicode_overlay(
                surface,
                int(clamp(px, 8, renderer.width - width - 8)),
                int(clamp(py, 24, renderer.height - 120)),
                node.label,
                node.color,
                alpha=int(255 * clamp(fade * 1.15, 0.0, 1.0)),
            )
