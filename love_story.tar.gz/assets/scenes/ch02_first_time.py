"""CH2 FIRST TIME: 'hello_world' — Instagram notification and radial rose colour bloom."""

import math
import pygame

from ascii_assets.objects import apply_radial_color_wave, draw_phone_screen
from ascii_assets.scenery import Starfield
from engine.easing import clamp, lerp_color, smoothstep
from engine.palette import (
    CREAM,
    DUSTY_ROSE,
    FADED_TEAL,
    HOT_ROSE,
    MONO_LIGHT,
    MONO_MID,
    WARM_AMBER,
)
from engine.particles import ParticleSystem
from engine.renderer import AsciiRenderer
from engine.scene import Scene
from story import HER_IG_HANDLE


class Ch02FirstTimeScene(Scene):
    """The Instagram meeting where a single point of dusty rose spreads across the terminal."""

    def __init__(self) -> None:
        super().__init__(2)
        self.stars: Starfield = Starfield(120, 42, count=75, seed=202)
        self.particles: ParticleSystem = ParticleSystem(seed=202)
        self.ping_triggered: bool = False

    def enter(self) -> None:
        super().enter()
        self.particles.clear()
        self.ping_triggered = False

    def update(self, dt: float) -> None:
        super().update(dt)
        self.stars.update(dt, vx=-1.5, vy=0.4)
        if self.time >= 5.2 and not self.ping_triggered:
            self.ping_triggered = True
            self.particles.spawn_heart_burst(60.0, 15.0, count=28)
        self.particles.update(dt)

    def draw(self, renderer: AsciiRenderer, surface: pygame.Surface) -> None:
        # Notification arrives at t = 5.2s; color blooms outward from center of phone
        has_ping = self.time >= 5.2
        color_prog = smoothstep(5.2, 13.5, self.time)

        if color_prog > 0.05:
            self.stars.draw(renderer, self.time, brightness=color_prog)

        # Ambient terminal log panels flanking the phone
        left_col = lerp_color(MONO_MID, FADED_TEAL, color_prog)
        right_col = lerp_color(MONO_MID, DUSTY_ROSE, color_prog)

        renderer.draw_box(4, 6, 34, 22, left_col, title="network_socket // ig_dm")
        logs = [
            "GET /feed/midnight HTTP/1.1",
            "Host: instagram.com",
            "Mode: passive_scroll",
            "",
            ">> INTERRUPT_REQUEST (IRQ_07)" if has_ping else ">> awaiting packets...",
            f"From: {HER_IG_HANDLE}" if has_ping else "",
            "Payload: 'typing...'" if self.time > 7.0 else "",
            "Shader: ROSE_PASTEL_70S" if self.time > 9.5 else "",
            "Status: STACK_REINSTALLED" if self.time > 12.0 else "",
        ]
        for i, line in enumerate(logs):
            if line:
                renderer.draw_text(
                    6,
                    8 + i * 2,
                    line,
                    lerp_color(MONO_LIGHT, WARM_AMBER if "INTERRUPT" in line else CREAM, color_prog),
                    glow=0.35 * color_prog,
                )

        # Centerpiece ASCII phone screen
        draw_phone_screen(
            renderer,
            col=42,
            row=4,
            width=36,
            height=26,
            t=self.time,
            color_progress=color_prog,
            show_notification=has_ping,
        )

        # Right panel: RGB color histogram blooming to life
        renderer.draw_box(82, 6, 34, 22, right_col, title="palette.load(tv_girl)")
        channels = [
            ("DUSTY_ROSE ", DUSTY_ROSE, 0.92),
            ("FADED_TEAL ", FADED_TEAL, 0.84),
            ("SUNSET_GLOW", WARM_AMBER, 0.78),
            ("VHS_CREAM  ", CREAM, 0.88),
        ]
        for idx, (label, ch_col, target_val) in enumerate(channels):
            ry = 10 + idx * 4
            fill = int(round(target_val * 16 * color_prog))
            bar = "#" * fill + "." * (16 - fill)
            renderer.draw_text(84, ry, label, lerp_color(MONO_MID, ch_col, color_prog))
            renderer.draw_text(
                84,
                ry + 1,
                f"[{bar}] {int(color_prog * 100):3d}%",
                lerp_color(MONO_MID, ch_col, color_prog),
                glow=0.45 * color_prog,
            )

        # Expanding radial ring of rose & gold when notification hits
        if 5.2 <= self.time <= 16.0:
            wave_r = (self.time - 5.2) * 8.5
            apply_radial_color_wave(renderer, 60, 15, wave_r, self.time)

        # Single glowing point of rose just before burst
        if 4.4 <= self.time < 5.4:
            pulse = 0.6 + 0.4 * math.sin(self.time * 16.0)
            renderer.set_cell(60, 14, "@", HOT_ROSE, glow=pulse)

        self.particles.draw(renderer)
        self.narrator.draw_narration_panel(
            renderer,
            border_color=lerp_color(MONO_MID, DUSTY_ROSE, clamp(color_prog, 0.0, 1.0)),
        )
        renderer.render_to_surface(surface)
