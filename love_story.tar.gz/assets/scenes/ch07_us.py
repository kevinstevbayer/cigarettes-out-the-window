"""CH7 US: 'merge(you, me)' — Two ASCII figures swaying on a vinyl floor, git log, Big-O card."""

import pygame

from ascii_assets.figures import draw_couple_swaying
from ascii_assets.objects import draw_vinyl_record
from engine.palette import CREAM, DUSTY_ROSE, FADED_TEAL, MINT_GLOW, WARM_AMBER
from engine.particles import ParticleSystem
from engine.renderer import AsciiRenderer
from engine.scene import Scene
from story import US_GIT_LOG


class Ch07UsScene(Scene):
    """Steve and Shana swaying together on a vinyl floor beside their scrolling git log."""

    def __init__(self) -> None:
        super().__init__(7)
        self.particles: ParticleSystem = ParticleSystem(seed=707)
        self.note_timer: float = 0.0

    def enter(self) -> None:
        super().enter()
        self.particles.clear()

    def update(self, dt: float) -> None:
        super().update(dt)
        self.note_timer += dt
        if self.note_timer >= 0.45:
            self.note_timer = 0.0
            self.particles.spawn_ember(30.0, 14.0)
        self.particles.update(dt)

    def draw(self, renderer: AsciiRenderer, surface: pygame.Surface) -> None:
        # Left side: Spinning vinyl record perspective floor + swaying couple
        draw_vinyl_record(
            renderer,
            cx=30,
            cy=24,
            radius=9,
            t=self.time,
            rpm_speed=1.8,
        )
        draw_couple_swaying(
            renderer,
            center_col=30,
            base_row=22,
            t=self.time,
            holding_hands=True,
        )

        # Right side: Git commit log of our story
        renderer.draw_box(
            56,
            4,
            60,
            19,
            FADED_TEAL,
            title="git log --oneline --graph us",
            fill_bg=(16, 13, 22),
            glow=0.35,
        )

        shown_commits = min(len(US_GIT_LOG), int(self.time / 2.6) + 1)
        for i in range(shown_commits):
            sha, scope, msg = US_GIT_LOG[i]
            ry = 6 + i * 2
            renderer.draw_text(58, ry, f"* {sha}", WARM_AMBER, glow=0.45)
            renderer.draw_text(69, ry, f"({scope})", DUSTY_ROSE, glow=0.4)
            renderer.draw_text(58, ry + 1, f"|   {msg}", CREAM)

        # Bottom right: Big-O Complexity Analysis Card
        if self.time >= 10.5:
            renderer.draw_box(
                56,
                24,
                60,
                9,
                DUSTY_ROSE,
                title="complexity_benchmark // shana.h",
                fill_bg=(20, 14, 26),
                glow=0.5,
            )
            renderer.draw_text(
                58, 26, "Time Complexity  : O(forever)   [optimal]", WARM_AMBER, glow=0.6
            )
            renderer.draw_text(
                58, 28, "Space Complexity : 100% of Steve's memory", FADED_TEAL, glow=0.5
            )
            renderer.draw_text(
                58, 30, "Merge Conflicts  : 0 (auto-resolved with ♥)", MINT_GLOW, glow=0.5
            )

        self.particles.draw(renderer)
        self.narrator.draw_narration_panel(renderer)
        renderer.render_to_surface(surface)
