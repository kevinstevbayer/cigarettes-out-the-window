"""CH9 EPILOGUE: 'return 0;' — Credits card, deployment summary, fade to prologue flame."""

import pygame

from ascii_assets.objects import draw_flame
from engine.easing import smoothstep
from engine.palette import CREAM, DUSTY_ROSE, FADED_TEAL, MINT_GLOW, WARM_AMBER
from engine.particles import ParticleSystem
from engine.renderer import AsciiRenderer
from engine.scene import Scene
from story import EPILOGUE_CREDITS, HER_NAME, MY_NAME, RELEASE_DATE, VERSION_TAG


class Ch09EpilogueScene(Scene):
    """Warm closing credits and return to the single flickering ember from the prologue."""

    def __init__(self) -> None:
        super().__init__(9)
        self.particles: ParticleSystem = ParticleSystem(seed=909)
        self.ember_accum: float = 0.0

    def enter(self) -> None:
        super().enter()
        self.particles.clear()

    def update(self, dt: float) -> None:
        super().update(dt)
        self.ember_accum += dt
        if self.ember_accum >= 0.11:
            self.ember_accum = 0.0
            self.particles.spawn_ember(60.0, 27.0)
        self.particles.update(dt)

    def draw(self, renderer: AsciiRenderer, surface: pygame.Surface) -> None:
        # Credits card in upper half
        renderer.draw_box(
            18,
            3,
            84,
            19,
            DUSTY_ROSE,
            title=f"release_manifest // {VERSION_TAG}",
            fill_bg=(16, 12, 22),
            glow=0.45,
        )

        renderer.draw_centered_text(
            5,
            f"Written, compiled, and deployed by {MY_NAME}.",
            CREAM,
            glow=0.65,
        )
        renderer.draw_centered_text(
            6,
            f"No bugs, only features. For {HER_NAME}.",
            WARM_AMBER,
            glow=0.75,
        )

        for idx, (role, value) in enumerate(EPILOGUE_CREDITS):
            row = 8 + idx
            if row < 20:
                appear = smoothstep(idx * 1.1, idx * 1.1 + 1.5, self.time)
                if appear > 0.1:
                    renderer.draw_text(
                        24, row, f"{role:<26}", FADED_TEAL, glow=0.35 * appear
                    )
                    renderer.draw_text(
                        52, row, f":  {value}", CREAM, glow=0.45 * appear
                    )

        renderer.draw_centered_text(
            20,
            f"Deployed: {RELEASE_DATE}  |  Press [R] to replay from Chapter 00",
            MINT_GLOW,
            glow=0.5,
        )

        # Single warm noise-driven flame below the credits card (circling back to Ch 00)
        draw_flame(
            renderer,
            cx=60,
            cy=28,
            t=self.time,
            scale=0.95,
            intensity=0.95,
        )

        self.particles.draw(renderer)
        self.narrator.draw_narration_panel(renderer)
        renderer.render_to_surface(surface)
