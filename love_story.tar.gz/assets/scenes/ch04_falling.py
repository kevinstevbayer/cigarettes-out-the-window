"""CH4 FALLING: 'gravity.exe' — Spinning vinyl record, upward parallax stars, 2:14 AM chat log."""

import pygame

from ascii_assets.objects import draw_vinyl_record
from ascii_assets.scenery import Starfield
from engine.easing import smoothstep
from engine.palette import CREAM, DUSTY_ROSE, FADED_TEAL, MONO_MID, WARM_AMBER
from engine.renderer import AsciiRenderer
from engine.scene import Scene
from story import FALLING_CHAT_MESSAGES


class Ch04FallingScene(Scene):
    """Spinning vinyl record in warm light while stars rush upward and 2 AM chats scroll."""

    def __init__(self) -> None:
        super().__init__(4)
        # Upward-rushing parallax stars create the sensation of falling through the night sky
        self.stars: Starfield = Starfield(120, 42, count=110, seed=404)

    def update(self, dt: float) -> None:
        super().update(dt)
        self.stars.update(dt, vx=0.0, vy=-11.5)

    def draw(self, renderer: AsciiRenderer, surface: pygame.Surface) -> None:
        self.stars.draw(renderer, self.time, brightness=0.85)

        # Left centerpiece: Spinning vinyl record
        draw_vinyl_record(
            renderer,
            cx=34,
            cy=17,
            radius=12,
            t=self.time,
            rpm_speed=2.6,
        )
        renderer.draw_text(
            18,
            31,
            "♫ playing: lovers_rock_late_night.vinyl [33 RPM]",
            WARM_AMBER,
            glow=0.45,
        )

        # Right panel: Scrolling late-night chat history with timestamps
        renderer.draw_box(
            64,
            4,
            52,
            28,
            DUSTY_ROSE,
            title="chat_history // 02:14 AM",
            fill_bg=(16, 12, 22),
            glow=0.35,
        )

        visible_count = min(len(FALLING_CHAT_MESSAGES), int(self.time / 2.2) + 1)
        start_idx = max(0, visible_count - 7)
        shown_msgs = FALLING_CHAT_MESSAGES[start_idx:visible_count]

        ry = 6
        for timestamp, sender, msg in shown_msgs:
            if sender == "shana":
                tag_col = DUSTY_ROSE
            elif sender == "steve":
                tag_col = FADED_TEAL
            else:
                tag_col = MONO_MID

            renderer.draw_text(66, ry, f"[{timestamp}] {sender}:", tag_col, glow=0.35)
            renderer.draw_text(68, ry + 1, msg[:46], CREAM, glow=0.25)
            ry += 3

        # Gravity telemetry indicator
        vel = 9.81 * self.time
        alpha = smoothstep(1.0, 5.0, self.time)
        renderer.draw_text(
            8,
            4,
            f"velocity_y: -{vel:5.1f} m/s  |  alt: freefall",
            FADED_TEAL,
            glow=0.35 * alpha,
        )

        self.narrator.draw_narration_panel(renderer)
        renderer.render_to_surface(surface)
