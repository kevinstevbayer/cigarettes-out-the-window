"""CH8 THE QUESTION: 'main()' — Night sky, moon, fireflies, dodging [N], fireworks on [Y]."""

import math
import random
from typing import Tuple
import pygame

from ascii_assets.eyes import ProceduralEyes
from ascii_assets.objects import draw_heart_field, draw_moon
from ascii_assets.scenery import Starfield
from engine.easing import smoothstep
from engine.palette import (
    CREAM,
    DUSTY_ROSE,
    FADED_TEAL,
    HOT_ROSE,
    MINT_GLOW,
    SUNSET_ORANGE,
    WARM_AMBER,
)
from engine.particles import ParticleSystem
from engine.renderer import AsciiRenderer
from engine.scene import Scene
from story import (
    DODGE_TAUNTS,
    FINAL_LETTER_LINES,
    HER_NAME,
    QUESTION_ACCEPTED_TEXT,
    THE_QUESTION_PROMPT,
)


class Ch08TheQuestionScene(Scene):
    """Interactive climax: moonlit sky, eyes with starlight, heartfelt letter, and [Y/n] prompt."""

    def __init__(self) -> None:
        super().__init__(8)
        self.stars: Starfield = Starfield(120, 42, count=90, seed=808)
        self.eyes: ProceduralEyes = ProceduralEyes()
        self.particles: ParticleSystem = ParticleSystem(seed=808)
        self.rng: random.Random = random.Random(808)

        self.accepted: bool = False
        self.accepted_timer: float = 0.0
        self.firework_accum: float = 0.0
        self.firefly_accum: float = 0.0

        # Playful dodging [N] button coordinates (in grid cells) and taunt index
        self.no_btn_pos: Tuple[int, int] = (74, 31)
        self.yes_btn_pos: Tuple[int, int] = (42, 31)
        self.dodge_count: int = 0

    def enter(self) -> None:
        super().enter()
        self.particles.clear()
        self.accepted = False
        self.accepted_timer = 0.0
        self.no_btn_pos = (74, 31)
        self.yes_btn_pos = (42, 31)
        self.dodge_count = 0
        for _ in range(22):
            self.particles.spawn_firefly(120, 34)

    def _dodge_no_button(self) -> None:
        """Teleport the [ N ] button to a safe random location so only [ Y ] can be chosen."""
        self.dodge_count += 1
        new_c = self.rng.randint(14, 96)
        new_r = self.rng.randint(20, 32)
        self.no_btn_pos = (new_c, new_r)
        self.particles.spawn_ember(float(new_c), float(new_r))

    def _accept_yes(self) -> None:
        """Trigger the celebratory hearts-and-confetti fireworks finale."""
        if self.accepted:
            return
        self.accepted = True
        self.accepted_timer = 0.0
        self.particles.spawn_heart_burst(60.0, 16.0, count=55)
        self.particles.spawn_heart_burst(32.0, 14.0, count=40)
        self.particles.spawn_heart_burst(88.0, 14.0, count=40)

    def handle_event(self, event: pygame.event.Event) -> None:
        if event.type == pygame.KEYDOWN:
            if event.key in (pygame.K_y, pygame.K_RETURN):
                self._accept_yes()
            elif event.key == pygame.K_n and not self.accepted:
                self._dodge_no_button()
        elif event.type == pygame.MOUSEMOTION and not self.accepted:
            # Check if cursor gets close to the [ N ] button and make it dodge away
            mx, my = event.pos
            nc, nr = self.no_btn_pos
            npx = (nc + 4) * 10
            npy = (nr + 1) * 16
            if math.hypot(mx - npx, my - npy) < 75:
                self._dodge_no_button()
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            mx, my = event.pos
            yc, yr = self.yes_btn_pos
            ypx = (yc + 5) * 10
            ypy = (yr + 1) * 16
            if math.hypot(mx - ypx, my - ypy) < 85:
                self._accept_yes()
            elif not self.accepted:
                self._dodge_no_button()

    def update(self, dt: float) -> None:
        super().update(dt)
        self.stars.update(dt, vx=0.35, vy=0.0)
        self.eyes.update_natural_motion(
            self.time, look_at_viewer=True, happy_close=self.accepted
        )

        self.firefly_accum += dt
        if self.firefly_accum >= 0.35:
            self.firefly_accum = 0.0
            self.particles.spawn_firefly(120, 34)

        if self.accepted:
            self.accepted_timer += dt
            self.firework_accum += dt
            if self.firework_accum >= 0.48:
                self.firework_accum = 0.0
                fx = self.rng.uniform(20.0, 100.0)
                fy = self.rng.uniform(8.0, 22.0)
                self.particles.spawn_heart_burst(fx, fy, count=36)
            # After 8.5 seconds of celebration fireworks, advance chapter timer so SceneManager moves to Epilogue
            if self.accepted_timer >= 8.5:
                self.time = 10000.0

        self.particles.update(dt)

    def draw(self, renderer: AsciiRenderer, surface: pygame.Surface) -> None:
        self.stars.draw(renderer, self.time, brightness=0.9)

        # Drifting crescent moon in upper right sky
        moon_x = int(106 + math.sin(self.time * 0.25) * 2)
        draw_moon(renderer, cx=moon_x, cy=8, radius=4, t=self.time)

        # Gentle giant eyes in upper center with starlight
        self.eyes.draw_pair(
            renderer,
            center_col=60,
            center_row=10,
            t=self.time,
            scale=0.75,
            alpha=0.9,
            starlight_irises=True,
        )

        # Glowing banner of Shana's name in rose and gold
        shimmer = 0.5 + 0.5 * math.sin(self.time * 3.5)
        banner_col = WARM_AMBER if shimmer > 0.5 else DUSTY_ROSE
        renderer.draw_centered_text(
            18,
            f"✦  S H A N A  ✦",
            banner_col,
            glow=0.95,
        )

        if not self.accepted:
            # Final heartfelt letter box
            renderer.draw_box(
                20,
                19,
                80,
                11,
                DUSTY_ROSE,
                title=f"final_letter_for_{HER_NAME.lower()}.txt",
                fill_bg=(16, 12, 22),
                glow=0.45,
            )
            chars_budget = int(max(0.0, self.time - 1.5) * 36.0)
            for idx, line in enumerate(FINAL_LETTER_LINES):
                if chars_budget <= 0:
                    break
                shown = line[:chars_budget]
                chars_budget -= len(line)
                renderer.draw_centered_text(20 + idx, shown, CREAM, glow=0.35)

            # Prompt & Interactive [ Y ] / Dodging [ N ] buttons
            if self.time > 9.0:
                renderer.draw_centered_text(
                    30,
                    THE_QUESTION_PROMPT,
                    WARM_AMBER,
                    glow=0.85,
                )
                yc, yr = self.yes_btn_pos
                nc, nr = self.no_btn_pos
                renderer.draw_box(
                    yc, yr, 13, 3, MINT_GLOW, fill_bg=(18, 34, 28), glow=0.85
                )
                renderer.draw_text(yc + 2, yr + 1, "[ Y ] YES", CREAM, glow=0.9)

                renderer.draw_box(
                    nc, nr, 11, 3, DUSTY_ROSE, fill_bg=(28, 16, 22), glow=0.4
                )
                renderer.draw_text(nc + 2, nr + 1, "[ N ] no", DUSTY_ROSE)

                if self.dodge_count > 0:
                    taunt = DODGE_TAUNTS[(self.dodge_count - 1) % len(DODGE_TAUNTS)]
                    renderer.draw_centered_text(34, taunt, FADED_TEAL, glow=0.6)
        else:
            # Celebration state after pressing Y
            draw_heart_field(
                renderer, cx=60, cy=24, scale=0.75, t=self.time, pulse_bpm=88.0
            )
            renderer.draw_centered_text(
                32,
                QUESTION_ACCEPTED_TEXT,
                MINT_GLOW,
                glow=0.95,
            )
            renderer.draw_centered_text(
                34,
                f"Best decision in {HER_NAME} & Steve's git history ♥",
                WARM_AMBER,
                glow=0.85,
            )

        self.particles.draw(renderer)
        self.narrator.draw_narration_panel(
            renderer, border_color=HOT_ROSE if self.accepted else DUSTY_ROSE
        )
        renderer.render_to_surface(surface)
