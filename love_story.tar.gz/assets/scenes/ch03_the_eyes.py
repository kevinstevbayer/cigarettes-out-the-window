"""CH3 THE EYES: 'render(eyes)' — Centrepiece procedural ASCII eyes with iris constellations."""

import math
import pygame

from ascii_assets.eyes import ProceduralEyes
from ascii_assets.scenery import Starfield
from engine.easing import smoothstep
from engine.palette import CREAM, DUSTY_ROSE, FADED_TEAL, WARM_AMBER
from engine.particles import ParticleSystem
from engine.renderer import AsciiRenderer
from engine.scene import Scene
from story import EYES_FUNCTION_CAPTIONS


class Ch03TheEyesScene(Scene):
    """The centrepiece chapter: large noise-textured ASCII eyes resolving out of the dark."""

    def __init__(self) -> None:
        super().__init__(3)
        self.eyes: ProceduralEyes = ProceduralEyes()
        self.stars: Starfield = Starfield(120, 42, count=85, seed=303)
        self.particles: ParticleSystem = ParticleSystem(seed=303)
        self.firefly_timer: float = 0.0

    def enter(self) -> None:
        super().enter()
        self.particles.clear()
        for _ in range(18):
            self.particles.spawn_firefly(120, 34)

    def update(self, dt: float) -> None:
        super().update(dt)
        self.stars.update(dt, vx=0.6, vy=-0.2)
        # Look around softly until t=14s, then lock gaze directly onto the viewer
        look_direct = self.time >= 14.0
        self.eyes.update_natural_motion(self.time, look_at_viewer=look_direct)

        self.firefly_timer += dt
        if self.firefly_timer >= 0.45:
            self.firefly_timer = 0.0
            self.particles.spawn_firefly(120, 34)
        self.particles.update(dt)

    def draw(self, renderer: AsciiRenderer, surface: pygame.Surface) -> None:
        fade_in = smoothstep(0.8, 6.5, self.time)
        self.stars.draw(renderer, self.time, brightness=0.45 * fade_in)

        # Draw the large procedural ASCII eyes in the center of the terminal
        self.eyes.draw_pair(
            renderer,
            center_col=60,
            center_row=16,
            t=self.time,
            scale=1.18,
            alpha=fade_in,
            starlight_irises=True,
        )

        # Orbiting constellation particles around the irises
        for i in range(8):
            angle = self.time * 0.65 + i * (math.tau / 8.0)
            for eye_cx in (60 - 27, 60 + 27):
                ox = int(round(eye_cx + math.cos(angle) * 19.0))
                oy = int(round(16 + math.sin(angle) * 8.5))
                renderer.set_cell(
                    ox,
                    oy,
                    "*" if i % 2 == 0 else "+",
                    WARM_AMBER if i % 2 == 0 else FADED_TEAL,
                    glow=0.75 * fade_in,
                )

        # Function-call captions appearing progressively around the eyes
        caption_positions = [
            (6, 4, 3.5),
            (64, 4, 8.5),
            (6, 28, 14.0),
            (54, 28, 19.5),
        ]
        for idx, (col, row, trigger_t) in enumerate(caption_positions):
            if self.time >= trigger_t and idx < len(EYES_FUNCTION_CAPTIONS):
                fn_call, ret_val = EYES_FUNCTION_CAPTIONS[idx]
                c_alpha = smoothstep(trigger_t, trigger_t + 1.8, self.time)
                if c_alpha > 0.1:
                    renderer.draw_text(col, row, fn_call, FADED_TEAL, glow=0.45 * c_alpha)
                    renderer.draw_text(col + 2, row + 1, ret_val, WARM_AMBER, glow=0.55 * c_alpha)

        if self.time > 22.0:
            renderer.draw_centered_text(
                31,
                "// mesmerizing.",
                DUSTY_ROSE,
                glow=0.85,
            )

        self.particles.draw(renderer)
        self.narrator.draw_narration_panel(renderer, border_color=DUSTY_ROSE, text_color=CREAM)
        renderer.render_to_surface(surface)
