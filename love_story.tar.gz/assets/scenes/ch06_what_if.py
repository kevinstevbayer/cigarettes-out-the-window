"""CH6 WHAT IF: 'try / except' — Stack traces overwritten by calm warm text & gentle eyes."""

import random
import pygame

from ascii_assets.eyes import ProceduralEyes
from engine.easing import smoothstep
from engine.palette import (
    CREAM,
    DUSTY_ROSE,
    ERROR_CORAL,
    FADED_TEAL,
    MINT_GLOW,
    WARM_AMBER,
)
from engine.renderer import AsciiRenderer
from engine.scene import Scene
from story import FEAR_STACK_TRACES


class Ch06WhatIfScene(Scene):
    """The fear chapter: flickering stack traces calm down into warm reassurance and her eyes."""

    def __init__(self) -> None:
        super().__init__(6)
        self.eyes: ProceduralEyes = ProceduralEyes()
        self.rng: random.Random = random.Random(606)

    def update(self, dt: float) -> None:
        super().update(dt)
        self.eyes.update_natural_motion(self.time, look_at_viewer=True)

    def draw(self, renderer: AsciiRenderer, surface: pygame.Surface) -> None:
        # Code block header
        calm_ratio = smoothstep(10.0, 20.0, self.time)
        box_col = ERROR_CORAL if calm_ratio < 0.5 else FADED_TEAL
        renderer.draw_box(
            6,
            4,
            108,
            28,
            box_col,
            title="runtime_monitor // try_except_block.py",
            fill_bg=(16, 12, 20) if calm_ratio > 0.4 else None,
            glow=0.35,
        )

        # Eyes return as a gentle, reassuring glow from t=12s onward. Drawn after the box
        # (its background fill clears cells) but before the text so the text stays readable.
        eyes_alpha = smoothstep(11.5, 18.5, self.time) * 0.65
        if eyes_alpha > 0.02:
            self.eyes.draw_pair(
                renderer,
                center_col=60,
                center_row=12,
                t=self.time,
                scale=0.95,
                alpha=eyes_alpha,
                starlight_irises=True,
            )

        renderer.draw_text(10, 6, "try:", WARM_AMBER, glow=0.4)
        renderer.draw_text(14, 7, "steve.tell_shana_everything()", CREAM, glow=0.3)

        # Render each fear stack trace, then overwrite it with warm calm text
        for idx, (err_line, calm_line) in enumerate(FEAR_STACK_TRACES):
            appear_t = 2.0 + idx * 2.2
            resolve_t = 11.5 + idx * 2.4
            row = 10 + idx * 4

            if self.time < appear_t:
                continue

            if self.time < resolve_t:
                # Flickering red/coral stack trace
                jitter = self.rng.choice([-1, 0, 0, 1]) if self.time < 11.0 else 0
                renderer.draw_text(
                    12 + jitter,
                    row,
                    f"[!] {err_line}",
                    ERROR_CORAL,
                    glow=0.65,
                )
                renderer.draw_text(
                    16,
                    row + 1,
                    "at overthinking_thread.c:404 -> status: PANIC",
                    DUSTY_ROSE,
                )
            else:
                # Overwritten cleanly by warm reassuring text
                prog = smoothstep(resolve_t, resolve_t + 1.4, self.time)
                chars = int(len(calm_line) * prog)
                renderer.draw_text(
                    12,
                    row,
                    f"[✓] {calm_line[:chars]}",
                    MINT_GLOW if idx < 3 else WARM_AMBER,
                    glow=0.65,
                )
                renderer.draw_text(
                    16,
                    row + 1,
                    "// exception handled gracefully by her smile",
                    FADED_TEAL,
                    glow=0.35,
                )

        if self.time >= 20.5:
            renderer.draw_centered_text(
                28,
                "except FearError: pass",
                WARM_AMBER,
                glow=0.9,
            )

        self.narrator.draw_narration_panel(renderer)
        renderer.render_to_surface(surface)
