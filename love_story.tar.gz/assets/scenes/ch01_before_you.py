"""CH1 BEFORE YOU: 'version 0.1' — Greyscale night city in rain, one lit window, endless phone scroll."""

import pygame

from ascii_assets.objects import draw_coffee_cup, draw_phone_screen
from ascii_assets.scenery import draw_night_city
from engine.palette import MONO_DARK, MONO_LIGHT, MONO_MID, WARM_AMBER
from engine.particles import ParticleSystem
from engine.renderer import AsciiRenderer
from engine.scene import Scene


class Ch01BeforeYouScene(Scene):
    """Sparse greyscale rainy city and desk setup before Shana entered Steve's world."""

    def __init__(self) -> None:
        super().__init__(1)
        self.rain: ParticleSystem = ParticleSystem(seed=101)
        self.rain_accum: float = 0.0

    def enter(self) -> None:
        super().enter()
        self.rain.clear()
        for _ in range(45):
            self.rain.spawn_rain(120, monochrome=True)
            self.rain.update(0.05)

    def update(self, dt: float) -> None:
        super().update(dt)
        self.rain_accum += dt
        while self.rain_accum >= 0.035:
            self.rain_accum -= 0.035
            self.rain.spawn_rain(120, monochrome=True)
        self.rain.update(dt)

    def draw(self, renderer: AsciiRenderer, surface: pygame.Surface) -> None:
        # Rain streaks in background
        self.rain.draw(renderer)

        # Greyscale night city skyline on the left with a single warm lit window
        draw_night_city(renderer, horizon_row=31, t=self.time, color_warmth=0.05)

        # Window frame border separating city and desk
        renderer.draw_box(
            2, 3, 72, 30, MONO_MID, title="window_pane // rain.log"
        )

        # Desk and coffee cup on bottom right
        draw_coffee_cup(renderer, col=78, row=28, t=self.time, warmth=0.0)
        renderer.draw_text(76, 32, "====================", MONO_DARK)

        # Monochrome phone scrolling endlessly on the right
        draw_phone_screen(
            renderer,
            col=86,
            row=5,
            width=30,
            height=22,
            t=self.time,
            color_progress=0.0,
            show_notification=False,
        )

        # Monotonous status telemetry
        uptime = int(self.time * 3600) + 84200
        renderer.draw_text(
            6,
            33,
            f"status: routine_loop(day={uptime // 3600}) | color_channels: 1 (GREY) | exceptions: 0",
            MONO_LIGHT,
        )
        renderer.draw_text(
            48,
            12,
            "<- one lit window",
            WARM_AMBER,
            glow=0.35,
        )

        self.narrator.draw_narration_panel(
            renderer, border_color=MONO_MID, text_color=MONO_LIGHT
        )
        renderer.render_to_surface(surface)
