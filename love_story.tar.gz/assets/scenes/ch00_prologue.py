"""CH0 PROLOGUE: 'cursor.blink()' — Dark terminal, blinking cursor, noise-driven flame."""

import math
import pygame

from ascii_assets.objects import draw_flame
from engine.easing import smoothstep
from engine.palette import CREAM, DUSTY_ROSE, FADED_TEAL, MONO_MID, WARM_AMBER
from engine.particles import ParticleSystem
from engine.renderer import AsciiRenderer
from engine.scene import Scene
from story import HER_NAME, MY_NAME


class Ch00PrologueScene(Scene):
    """Steve trying to compile a love letter in a dark terminal as a warm ember ignites."""

    def __init__(self) -> None:
        super().__init__(0)
        self.particles: ParticleSystem = ParticleSystem(seed=100)
        self.ember_accum: float = 0.0

    def enter(self) -> None:
        super().enter()
        self.particles.clear()
        self.ember_accum = 0.0

    def update(self, dt: float) -> None:
        super().update(dt)
        if self.time > 3.0:
            self.ember_accum += dt
            while self.ember_accum >= 0.09:
                self.ember_accum -= 0.09
                self.particles.spawn_ember(60.0, 18.0)
        self.particles.update(dt)

    def draw(self, renderer: AsciiRenderer, surface: pygame.Surface) -> None:
        cx = renderer.cols // 2
        cy = 18

        # Terminal command header typing in at top left
        cmd = f"{MY_NAME.lower()}@midnight:~$ gcc -O3 draft_for_{HER_NAME.lower()}.c -o love_story"
        typed_len = int(self.time * 22)
        renderer.draw_text(6, 4, cmd[:typed_len], FADED_TEAL, glow=0.35)

        if self.time > 2.2:
            err_msg = "draft_099.c:14:2: error: feelings exceed standard buffer size"
            renderer.draw_text(6, 6, err_msg, DUSTY_ROSE, glow=0.3)
        if self.time > 4.0:
            retry_msg = ">> switching renderer to: ASCII_LIGHT_SHADER_V1..."
            renderer.draw_text(6, 7, retry_msg, WARM_AMBER, glow=0.45)

        # Before 2.5s: lonely blinking cursor in the center of the dark screen
        if self.time < 3.2:
            if int(self.time * 2.2) % 2 == 0:
                renderer.set_cell(cx, cy, "█", WARM_AMBER, glow=0.9)
        else:
            # Noise-driven warm light source / flame grows from the cursor
            growth = smoothstep(3.0, 10.0, self.time)
            breathe = 1.0 + 0.08 * math.sin(self.time * 2.5)
            draw_flame(
                renderer,
                cx,
                cy,
                self.time,
                scale=0.35 + 0.85 * growth * breathe,
                intensity=0.4 + 0.6 * growth,
            )

        # Faint pre-echo of the eyes motif glinting in the dark around t=14s
        if self.time > 13.5:
            glint = smoothstep(13.5, 17.5, self.time) * (0.6 + 0.4 * math.sin(self.time * 3.0))
            renderer.draw_text(cx - 12, 11, "( * )", CREAM, glow=glint * 0.8)
            renderer.draw_text(cx + 8, 11, "( * )", CREAM, glow=glint * 0.8)
            renderer.draw_centered_text(
                28,
                f"// target_recipient: {HER_NAME} (CSE)",
                MONO_MID,
                glow=0.25,
            )

        self.particles.draw(renderer)
        self.narrator.draw_narration_panel(renderer)
        renderer.render_to_surface(surface)
