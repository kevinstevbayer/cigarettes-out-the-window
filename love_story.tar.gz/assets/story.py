"""All personalizable story strings, narration scripts, easter eggs, and metadata.

Edit this file to customize names, dates, messages, or timings without touching engine logic.
"""

from dataclasses import dataclass
from typing import List, Tuple

# =====================================================================================
#  MAKE IT YOURS - the lines below marked  <<< REAL MEMORY >>>  are placeholders I invented
#  to give the story its shape. Swap them for what actually happened. Real details are what
#  will make her feel seen:
#    * HER_IG_HANDLE, PHONE_* lines            (Chapter 2 phone screen)
#    * FALLING_CHAT_MESSAGES                   (Chapter 4 late-night chat)
#    * US_GIT_LOG                              (Chapter 7 commit history)
#    * FINAL_LETTER_LINES                      (Chapter 8 letter - make it yours, in your words)
#    * RELEASE_DATE                            (Chapter 9 credits)
# =====================================================================================

# Core Personalization Metadata
HER_NAME: str = "Shana"
MY_NAME: str = "Steve"
HER_MAJOR: str = "Computer Science & Engineering"
MEETING_PLATFORM: str = "Instagram"
HER_IG_HANDLE: str = "@shana.cse"  # <<< REAL MEMORY >>> put her real handle (or leave it vague)

# Chapter 2 phone screen: the first messages (invented placeholders)  <<< REAL MEMORY >>>
PHONE_INCOMING_LINES: Tuple[str, str] = ("shana: hey! you like TV Girl", "       too??")
PHONE_OUTGOING_LINE: str = "steve: literally every album"
RELEASE_DATE: str = "November 2026"
VERSION_TAG: str = "v1.0.0-shana"

# Subtle TV Girl Song Title Easter Eggs (No lyrics quoted; titles only as ambient metadata)
TV_GIRL_EASTER_EGGS: List[str] = [
    "now_playing: lovers_rock.wav",
    "track_02: birds_dont_sing.flac",
    "cassette_b: cigarettes_out_the_window.mp3",
    "tape_loop: blue_hair.ogg",
    "radio_freq: not_allowed_89.5fm",
    "vinyl_spin: taking_what_is_not_yours.wav",
    "late_night: loving_machine.aac",
]


@dataclass(frozen=True)
class NarrationCue:
    """Represents a timed line of narration spoken by Steve in the terminal."""
    start_time: float
    text: str
    speed_multiplier: float = 1.0
    pause_after: float = 1.2


@dataclass(frozen=True)
class ChapterMeta:
    """Metadata and narration cues for a single story chapter."""
    index: int
    code_title: str
    subtitle: str
    easter_egg: str
    cues: Tuple[NarrationCue, ...]


CHAPTERS_STORY: dict[int, ChapterMeta] = {
    0: ChapterMeta(
        index=0,
        code_title="cursor.blink()",
        subtitle="CHAPTER 00 // THE UNCOMPILED DRAFT",
        easter_egg="tty1 // 02:11 AM // buffer: unsent_letter.py",
        cues=(
            NarrationCue(1.5, f"I've tried to write this a hundred times, {HER_NAME}."),
            NarrationCue(5.5, "Every draft threw an exception."),
            NarrationCue(9.2, "Plain English felt too small, and C++ had too many pointers."),
            NarrationCue(13.8, "So I built a tiny universe out of terminal characters instead."),
            NarrationCue(17.8, "Compiling from source... please don't press Ctrl+C."),
        ),
    ),
    1: ChapterMeta(
        index=1,
        code_title="version 0.1",
        subtitle="CHAPTER 01 // BEFORE YOU",
        easter_egg="track_01: birds_dont_sing.flac // mono_mix",
        cues=(
            NarrationCue(1.5, "Before I knew you, my days had zero syntax errors."),
            NarrationCue(6.0, "Wake up, attend lectures, push commits, watch rain on the glass."),
            NarrationCue(11.2, "Everything compiled. Nothing ran like it meant anything."),
            NarrationCue(16.5, "Just an infinite while-loop in greyscale, waiting for an interrupt."),
            NarrationCue(21.0, "Status: 200 OK. Emotional bandwidth: 0 kbps."),
        ),
    ),
    2: ChapterMeta(
        index=2,
        code_title="hello_world",
        subtitle="CHAPTER 02 // THE INTERRUPT REQUEST",
        easter_egg="tape_deck: lovers_rock.wav // stereo_bloom_enabled",
        cues=(
            NarrationCue(1.5, "We met the way people do now: through a screen, by accident."),
            NarrationCue(6.8, "Just another late night on Instagram when I wasn't expecting anything."),
            NarrationCue(12.2, "One notification. One profile circle. Three little dots: typing..."),
            NarrationCue(17.5, "And suddenly monochrome wasn't in my config anymore."),
            NarrationCue(22.0, "My whole stack got reinstalled in rose and gold."),
        ),
    ),
    3: ChapterMeta(
        index=3,
        code_title="render(eyes)",
        subtitle="CHAPTER 03 // KERNEL PANIC IN THE IRIS",
        easter_egg="shader_pass: cigarettes_out_the_window.glsl",
        cues=(
            NarrationCue(1.5, "The very first thing I noticed was your eyes."),
            NarrationCue(6.2, "I've seen high-resolution displays, raytracing, and 4K shaders."),
            NarrationCue(11.8, "Nothing has ever rendered anything like your eyes, Shana."),
            NarrationCue(17.5, "I wrote four hundred lines of noise math trying to capture them."),
            NarrationCue(23.5, "And the best comment I could leave in the source code was: // mesmerizing."),
        ),
    ),
    4: ChapterMeta(
        index=4,
        code_title="gravity.exe",
        subtitle="CHAPTER 04 // ASYNCHRONOUS LATE NIGHTS",
        easter_egg="vinyl_33rpm: blue_hair.ogg // side_a",
        cues=(
            NarrationCue(1.5, "One message turned into two hours. Two hours turned into 2:14 AM."),
            NarrationCue(6.8, "Talking about CS labs, music, stupid memes, and everything else."),
            NarrationCue(12.5, "They say people fall in love like stepping off a ledge."),
            NarrationCue(18.0, "I think I was already falling long before I looked down."),
        ),
    ),
    5: ChapterMeta(
        index=5,
        code_title="translate(love)",
        subtitle="CHAPTER 05 // ENCODING OVERFLOW",
        easter_egg="encoding: UTF-8 // lovers_rock_reprise.wav",
        cues=(
            NarrationCue(1.5, "As an engineer, I wanted a precise specification for how I feel."),
            NarrationCue(6.8, "So I queried thirty-four human languages and every compiler I know."),
            NarrationCue(12.5, "I looked for a language that says it right."),
            NarrationCue(17.5, "None of them has enough room. Not even with 64-bit floats."),
        ),
    ),
    6: ChapterMeta(
        index=6,
        code_title="try / except",
        subtitle="CHAPTER 06 // RUNTIME ANXIETY",
        easter_egg="debug_log: not_allowed.trace // catching_exceptions",
        cues=(
            NarrationCue(1.5, "Of course, my brain immediately ran worst-case analysis."),
            NarrationCue(6.5, "What if I mess this up? What if I'm just good at writing loops?"),
            NarrationCue(12.0, "Every insecurity threw a warning in the console."),
            NarrationCue(17.5, "Then I remembered the way you look at me, and the noise cleared."),
            NarrationCue(22.2, "except FearError: pass"),
        ),
    ),
    7: ChapterMeta(
        index=7,
        code_title="merge(you, me)",
        subtitle="CHAPTER 07 // ZERO MERGE CONFLICTS",
        easter_egg="git_branch: main // loving_machine.wav",
        cues=(
            NarrationCue(1.5, "Somehow, two separate repositories became one shared timeline."),
            NarrationCue(7.0, "Every conversation with you feels like code that works on the first try."),
            NarrationCue(13.0, "Time complexity of loving you: O(forever)."),
            NarrationCue(18.5, "Space complexity: you take up all my memory, and I don't want garbage collection."),
        ),
    ),
    8: ChapterMeta(
        index=8,
        code_title="main()",
        subtitle="CHAPTER 08 // THE PRODUCTION PROMPT",
        easter_egg="cassette_a: lovers_rock.wav // awaiting_stdin",
        cues=(
            NarrationCue(1.5, f"Hey, {HER_NAME}."),
            NarrationCue(4.5, "From a random Instagram scroll to the best part of every single day."),
            NarrationCue(9.8, "You are my favorite person to talk to, laugh with, and build a life beside."),
            NarrationCue(15.5, "I don't need a staging environment anymore. I'm ready for production."),
        ),
    ),
    9: ChapterMeta(
        index=9,
        code_title="return 0;",
        subtitle="CHAPTER 09 // EXIT CODE: HAPPY",
        easter_egg="tape_end // taking_what_is_not_yours.wav // fade_out",
        cues=(
            NarrationCue(2.0, f"Written, compiled, and deployed by {MY_NAME}."),
            NarrationCue(6.8, f"No bugs, only features. Dedicated to {HER_NAME}."),
            NarrationCue(12.0, "Process finished with exit code 0 (and a very full heart)."),
        ),
    ),
}

# Chapter 3 Function Call Captions
EYES_FUNCTION_CAPTIONS: List[Tuple[str, str]] = [
    ("notice(shana.eyes)", "-> returns: I forgot what I was saying"),
    ("measure_depth(iris)", "-> FloatOverflowError: depth exceeds max_float"),
    ("shader.compile(catchlight)", "-> status: 100% pure starlight"),
    ("steve.focus()", "-> Warning: thread permanently locked on her gaze"),
]

# Chapter 4 Late-Night Chat Timestamps  <<< REAL MEMORY >>> (all invented placeholders)
FALLING_CHAT_MESSAGES: List[Tuple[str, str, str]] = [
    ("11:42 PM", "steve", "wait you actually listen to TV Girl too??"),
    ("11:43 PM", "shana", "literally my whole playlist lol"),
    ("12:19 AM", "steve", "how are your eyes even real btw"),
    ("12:20 AM", "shana", "stoppp you're being dramatic"),
    ("01:08 AM", "steve", "do you ever sleep or just debug C code at night"),
    ("01:09 AM", "shana", "bold of you to assume my code compiles"),
    ("01:47 AM", "system", "seen 1:47 AM"),
    ("02:14 AM", "shana", "typing..."),
    ("02:15 AM", "steve", "// note to self: I am so completely done for."),
]

# Chapter 6 Fake Stack Traces & Calm Replacements
FEAR_STACK_TRACES: List[Tuple[str, str]] = [
    (
        "TypeError: expected smooth_confidence, got nervous_rambling",
        "Resolved: she laughs at your nerdy jokes anyway.",
    ),
    (
        "Warning: unsent_message sitting in Instagram drafts (line 42)",
        "Resolved: press send. Honesty beats perfection.",
    ),
    (
        "MemoryLeakError: thinking_about_shana consuming 99.8% CPU",
        "Resolved: marked as essential system process.",
    ),
    (
        "FearError: what if a screen is too small for how much I care?",
        "except FearError: pass  // she's right here.",
    ),
]

# Chapter 7 Git Log History  <<< REAL MEMORY >>>
US_GIT_LOG: List[Tuple[str, str, str]] = [
    ("a1b04f2", "init", "matched on Instagram on a night I wasn't looking"),
    ("c49e11a", "feat(eyes)", "noticed her eyes; forgot how to speak normally"),
    ("d83b90c", "feat(music)", "shared TV Girl tracks at 2 AM"),
    ("e92a77f", "fix(mood)", "can't stop smiling at my phone during lectures"),
    ("f01c88b", "refactor(life)", "refactored my whole life around her laugh"),
    ("99ff001", "merge", "git merge shana into steve -- conflict: none"),
]

# Chapter 8 Final Letter & Interactive Prompt  <<< REAL MEMORY >>> (rewrite in your own words)
FINAL_LETTER_LINES: List[str] = [
    f"Dear {HER_NAME},",
    "",
    "If I had to design my favorite moment from scratch,",
    "it would still just be looking into your eyes while",
    "a lo-fi song plays in the background and we lose track of time.",
    "",
    "You turned my quiet, greyscale routine into something",
    "warm, vivid, and full of life.",
]

THE_QUESTION_PROMPT: str = f"Will you be my person, {HER_NAME}?  [Y/n]"
QUESTION_ACCEPTED_TEXT: str = (
    f">> INPUT ACCEPTED: 'Y' // Building forever with {HER_NAME}..."
)
DODGE_TAUNTS: List[str] = [
    "// SyntaxError: 'N' is not a valid token",
    "// PermissionDenied: button refused to cooperate",
    "// Nice try, CSE major, that branch is unreachable!",
    "// SegmentationFault: 'N' moved to another memory address",
    "// Hint: the 'Y' key has O(1) lookup time :)",
]

# Chapter 9 Credits List
EPILOGUE_CREDITS: List[Tuple[str, str]] = [
    ("STARRING", f"{HER_NAME} & {MY_NAME}"),
    ("LEAD INSPIRATION", f"{HER_NAME}'s Mesmerizing Eyes"),
    ("AESTHETIC & MOOD", "Sun-Faded 70s VHS & Bedroom Pop"),
    ("SOUNDTRACK IN OUR HEADS", "TV Girl (Lovers Rock / Blue Hair)"),
    ("ENGINE ARCHITECTURE", "Custom Python ASCII Cell Shader"),
    ("TIME COMPLEXITY", "O(forever)"),
    ("SPACE COMPLEXITY", "100% of Steve's Heart"),
    ("COMPILED ON", RELEASE_DATE),
]
