"""Global configuration, resolution, timing constants, and visual effect toggles."""

from typing import Tuple

# Window & Display Settings
WINDOW_TITLE: str = "steve@terminal:~/love_story$ python3 compile_for_shana.py"
DEFAULT_WIDTH: int = 1280
DEFAULT_HEIGHT: int = 720
FPS: int = 60
ALLOW_RESIZE: bool = True

# ASCII Grid Dimensions (Fixed logical grid scaled smoothly to window size)
GRID_COLS: int = 120
GRID_ROWS: int = 42
CELL_WIDTH: int = 10
CELL_HEIGHT: int = 16
LOGICAL_WIDTH: int = GRID_COLS * CELL_WIDTH    # 1200
LOGICAL_HEIGHT: int = GRID_ROWS * CELL_HEIGHT  # 672

# Luminance Character Ramps
LUMINANCE_RAMP: str = " .:-=+*#%@"
DENSE_RAMP: str = " .'`^\",:;Il!i><~+_-?][}{1)(|\\/tfjrxnuvczXYUJCLQ0OZmwqpdbkhao*#MW&8%B@$"

# Font Preferences (Monospace stack with international fallbacks)
FONT_STACK: Tuple[str, ...] = (
    "JetBrains Mono",
    "Fira Code",
    "Consolas",
    "Menlo",
    "Monaco",
    "DejaVu Sans Mono",
    "Courier New",
    "monospace",
)
UNICODE_FONT_STACK: Tuple[str, ...] = (
    "Noto Sans Mono CJK JP",
    "Malgun Gothic",
    "Yu Gothic",
    "Meiryo",
    "Nirmala UI",
    "Latha",
    "Arial Unicode MS",
    "Segoe UI Symbol",
    "DejaVu Sans",
)

# Timing & Pacing (in seconds)
TITLE_CARD_DURATION: float = 3.2
CROSSFADE_DURATION: float = 1.4
TYPEWRITER_CHARS_PER_SEC: float = 26.0
FAST_TYPEWRITER_CPS: float = 45.0
SLOW_TYPEWRITER_CPS: float = 16.0
CURSOR_BLINK_INTERVAL: float = 0.48
AUTO_ADVANCE_CHAPTERS: bool = True

# Default durations per chapter before auto-advancing (Ch 8 waits for user input)
CHAPTER_DURATIONS: dict[int, float] = {
    0: 21.0,  # Prologue
    1: 25.0,  # Before You
    2: 27.0,  # First Time
    3: 32.0,  # The Eyes
    4: 26.0,  # Falling
    5: 26.0,  # Every Language
    6: 27.0,  # What If
    7: 28.0,  # Us
    8: 9999.0,  # The Question (waits for Y)
    9: 30.0,  # Epilogue
}

# Post-Processing & VHS Effect Toggles
ENABLE_SCANLINES: bool = True
SCANLINE_ALPHA: int = 38

ENABLE_FILM_GRAIN: bool = True
GRAIN_DENSITY: int = 180
GRAIN_ALPHA: int = 24

ENABLE_VIGNETTE: bool = True
VIGNETTE_STRENGTH: float = 0.65

ENABLE_VHS_GLITCH: bool = True
VHS_GLITCH_INTERVAL_MIN: float = 4.5
VHS_GLITCH_INTERVAL_MAX: float = 9.5
VHS_GLITCH_DURATION: float = 0.28

ENABLE_BLOOM: bool = True
BLOOM_THRESHOLD: float = 0.68
BLOOM_INTENSITY: float = 0.35

ENABLE_CHROMATIC_OFFSET: bool = True
