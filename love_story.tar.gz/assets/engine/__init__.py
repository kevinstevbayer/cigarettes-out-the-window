"""Core ASCII rendering, noise, particle, and post-processing engine package."""
