"""Manages chapter sequencing, title cards, crossfades, and top HUD metadata."""

from typing import List, Optional
import pygame

import config
from engine.easing import clamp, smoothstep
from engine.effects import PostProcessor
from engine.palette import BG_DEEP, CREAM, DUSTY_ROSE, FADED_TEAL, MONO_MID, WARM_AMBER
from engine.renderer import AsciiRenderer
from engine.scene import Scene


class SceneManager:
    """Orchestrates transitions, chapter title cards, and playback controls."""

    def __init__(
        self,
        scenes: List[Scene],
        renderer: AsciiRenderer,
        post_processor: PostProcessor,
    ) -> None:
        self.scenes: List[Scene] = scenes
        self.renderer: AsciiRenderer = renderer
        self.post: PostProcessor = post_processor

        self.current_idx: int = 0
        self.paused: bool = False
        self.title_card_timer: float = config.TITLE_CARD_DURATION
        self.fade_alpha: int = 255
        self.transition_target: Optional[int] = None
        self.transition_progress: float = 0.0

        self._fade_surface: pygame.Surface = pygame.Surface(
            (config.LOGICAL_WIDTH, config.LOGICAL_HEIGHT), pygame.SRCALPHA
        )

        if self.scenes:
            self.scenes[0].enter()

    @property
    def current_scene(self) -> Scene:
        """Return the currently active chapter scene."""
        return self.scenes[self.current_idx]

    def jump_to(self, index: int) -> None:
        """Start a smooth crossfade transition to the target chapter index."""
        target = index % len(self.scenes)
        if target == self.current_idx and self.transition_target is None:
            return
        self.transition_target = target
        self.transition_progress = 0.0
        self.post.trigger_glitch(duration=0.25, intensity=0.8)

    def next_chapter(self) -> None:
        """Advance to the next chapter in sequence."""
        if self.current_idx < len(self.scenes) - 1:
            self.jump_to(self.current_idx + 1)

    def prev_chapter(self) -> None:
        """Return to the previous chapter."""
        if self.current_idx > 0:
            self.jump_to(self.current_idx - 1)

    def restart_current(self) -> None:
        """Restart the current chapter or restart from Ch 0 if at the Epilogue."""
        if self.current_idx == len(self.scenes) - 1:
            self.jump_to(0)
        else:
            self.current_scene.enter()
            self.title_card_timer = config.TITLE_CARD_DURATION
            self.post.trigger_glitch(duration=0.22, intensity=0.6)

    def handle_event(self, event: pygame.event.Event) -> None:
        """Forward events to the active scene if not paused."""
        if not self.paused:
            self.current_scene.handle_event(event)

    def update(self, dt: float) -> None:
        """Update transitions, title cards, and active chapter simulation."""
        if self.paused:
            return

        # Handle crossfade transition
        if self.transition_target is not None:
            self.transition_progress += dt / config.CROSSFADE_DURATION
            if self.transition_progress >= 0.5 and self.current_idx != self.transition_target:
                self.current_scene.exit()
                self.current_idx = self.transition_target
                self.current_scene.enter()
                self.title_card_timer = config.TITLE_CARD_DURATION
            if self.transition_progress >= 1.0:
                self.transition_target = None
                self.transition_progress = 0.0

        # Title card overlay countdown
        if self.title_card_timer > 0.0:
            self.title_card_timer = max(0.0, self.title_card_timer - dt)

        self.current_scene.update(dt)

        # Auto-advance when chapter duration completes
        max_dur = config.CHAPTER_DURATIONS.get(self.current_idx, 28.0)
        if (
            config.AUTO_ADVANCE_CHAPTERS
            and self.current_scene.time >= max_dur
            and self.current_idx < len(self.scenes) - 1
            and self.transition_target is None
        ):
            self.next_chapter()

    def draw(self, surface: pygame.Surface) -> None:
        """Draw the active chapter, HUD bar, title card overlay, and crossfade."""
        self.renderer.clear()
        self.current_scene.draw(self.renderer, surface)
        self._draw_top_hud()

        if self.title_card_timer > 0.0:
            self._draw_title_card()

        # If scene hasn't already blitted custom overlays after render_to_surface,
        # scenes call renderer.render_to_surface internally so they can layer Unicode on top.
        # Therefore we draw HUD and title cards via a dedicated overlay pass.
        self._blit_hud_and_title_overlay(surface)

        if self.transition_target is not None:
            # Triangle wave fade out then fade in
            t = self.transition_progress
            alpha_norm = 1.0 - abs(2.0 * t - 1.0)
            alpha = int(clamp(smoothstep(0.0, 1.0, alpha_norm) * 255.0, 0.0, 255.0))
            self._fade_surface.fill((*BG_DEEP, alpha))
            surface.blit(self._fade_surface, (0, 0))

        if self.paused:
            self._draw_pause_badge(surface)

    def _draw_top_hud(self) -> None:
        """Placeholder for logical grid state; rendered directly in overlay pass."""

    def _blit_hud_and_title_overlay(self, surface: pygame.Surface) -> None:
        """Render top VHS status bar and chapter title card onto the pixel surface."""
        meta = self.current_scene.meta
        cw = self.renderer.cell_w
        ch = self.renderer.cell_h

        # Top terminal status bar
        pygame.draw.rect(surface, (18, 13, 24), (0, 0, self.renderer.width, ch + 4))
        pygame.draw.line(
            surface, DUSTY_ROSE, (0, ch + 4), (self.renderer.width, ch + 4), 1
        )

        left_status = f" [{meta.index:02d}/09] {meta.code_title} "
        mid_status = f"// {meta.easter_egg}"
        right_status = "[SPACE] Pause  [<-/->] Chapter  [R] Restart "

        l_surf = self.renderer.bold_font.render(left_status, True, WARM_AMBER)
        m_surf = self.renderer.font.render(mid_status, True, FADED_TEAL)
        r_surf = self.renderer.font.render(right_status, True, MONO_MID)

        surface.blit(l_surf, (cw, 2))
        surface.blit(m_surf, (cw * 28, 2))
        surface.blit(r_surf, (self.renderer.width - r_surf.get_width() - cw, 2))

        # Chapter Title Card Overlay during first seconds of chapter
        if self.title_card_timer > 0.0:
            ratio = self.title_card_timer / config.TITLE_CARD_DURATION
            if ratio > 0.8:
                fade = (1.0 - ratio) / 0.2
            elif ratio < 0.25:
                fade = ratio / 0.25
            else:
                fade = 1.0
            alpha = int(clamp(fade * 235.0, 0.0, 235.0))

            card_w = 540
            card_h = 96
            card_x = (self.renderer.width - card_w) // 2
            card_y = 48

            card = pygame.Surface((card_w, card_h), pygame.SRCALPHA)
            card.fill((16, 11, 22, alpha))
            pygame.draw.rect(card, (*DUSTY_ROSE, alpha), (0, 0, card_w, card_h), 2)
            pygame.draw.rect(
                card, (*FADED_TEAL, alpha // 2), (4, 4, card_w - 8, card_h - 8), 1
            )

            sub_surf = self.renderer.font.render(meta.subtitle, True, FADED_TEAL)
            sub_surf.set_alpha(alpha)
            title_surf = self.renderer.title_font.render(
                f">> {meta.code_title}", True, CREAM
            )
            title_surf.set_alpha(alpha)

            card.blit(sub_surf, ((card_w - sub_surf.get_width()) // 2, 16))
            card.blit(title_surf, ((card_w - title_surf.get_width()) // 2, 42))
            surface.blit(card, (card_x, card_y))

    def _draw_title_card(self) -> None:
        """No-op hook; title card is drawn with smooth alpha in _blit_hud_and_title_overlay."""

    def _draw_pause_badge(self, surface: pygame.Surface) -> None:
        """Render a VHS-styled PAUSED indicator in the upper right corner."""
        badge = self.renderer.title_font.render("|| VHS PAUSED", True, WARM_AMBER)
        bx = self.renderer.width - badge.get_width() - 32
        by = 36
        pygame.draw.rect(
            surface,
            (16, 12, 22),
            (bx - 12, by - 6, badge.get_width() + 24, badge.get_height() + 12),
        )
        pygame.draw.rect(
            surface,
            DUSTY_ROSE,
            (bx - 12, by - 6, badge.get_width() + 24, badge.get_height() + 12),
            2,
        )
        surface.blit(badge, (bx, by))
