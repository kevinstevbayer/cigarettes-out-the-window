"""Particle systems for sparks, hearts, rain, fireflies, confetti, and floating text."""

from dataclasses import dataclass
import math
import random
from typing import List, Optional
import pygame

from engine.easing import clamp
from engine.palette import (
    CREAM,
    DUSTY_ROSE,
    FADED_TEAL,
    HOT_ROSE,
    LAVENDER_HAZE,
    MINT_GLOW,
    MONO_LIGHT,
    MONO_MID,
    RGB,
    SUNSET_ORANGE,
    WARM_AMBER,
    scale_color,
)
from engine.renderer import AsciiRenderer


@dataclass
class Particle:
    """Single particle living in continuous grid coordinates."""
    x: float
    y: float
    vx: float
    vy: float
    char: str
    color: RGB
    life: float
    max_life: float
    glow: float = 0.3
    gravity: float = 0.0
    sway_amp: float = 0.0
    sway_freq: float = 2.0
    phase: float = 0.0
    unicode_label: Optional[str] = None
    target_x: Optional[float] = None
    target_y: Optional[float] = None


class ParticleSystem:
    """Manages emitters and updates/renders ASCII and Unicode particles."""

    def __init__(self, seed: int = 42) -> None:
        self.particles: List[Particle] = []
        self.rng: random.Random = random.Random(seed)
        self.clock: float = 0.0

    def clear(self) -> None:
        """Remove all active particles."""
        self.particles.clear()

    def spawn_ember(self, x: float, y: float) -> None:
        """Spawn a warm rising spark particle from a flame or light source."""
        angle = self.rng.uniform(-math.pi * 0.75, -math.pi * 0.25)
        speed = self.rng.uniform(2.5, 6.5)
        life = self.rng.uniform(1.0, 2.4)
        self.particles.append(
            Particle(
                x=x + self.rng.uniform(-1.5, 1.5),
                y=y,
                vx=math.cos(angle) * speed * 0.5,
                vy=math.sin(angle) * speed,
                char=self.rng.choice([".", "*", "+", "'", "`"]),
                color=self.rng.choice([WARM_AMBER, SUNSET_ORANGE, DUSTY_ROSE, CREAM]),
                life=life,
                max_life=life,
                glow=0.65,
                sway_amp=1.8,
                sway_freq=self.rng.uniform(2.0, 4.0),
                phase=self.rng.uniform(0.0, math.tau),
            )
        )

    def spawn_rain(self, cols: int, monochrome: bool = True) -> None:
        """Spawn falling rain streaks across the top of the screen."""
        x = self.rng.uniform(0, cols - 1)
        color = (
            self.rng.choice([MONO_MID, MONO_LIGHT])
            if monochrome
            else self.rng.choice([FADED_TEAL, MONO_LIGHT])
        )
        life = self.rng.uniform(1.2, 2.2)
        self.particles.append(
            Particle(
                x=x,
                y=-1.0,
                vx=-2.5,
                vy=self.rng.uniform(22.0, 32.0),
                char=self.rng.choice(["|", "/", ":", "."]),
                color=color,
                life=life,
                max_life=life,
                glow=0.1,
            )
        )

    def spawn_firefly(self, cols: int, rows: int) -> None:
        """Spawn a warm drifting firefly with sinusoidal motion."""
        life = self.rng.uniform(4.0, 8.0)
        self.particles.append(
            Particle(
                x=self.rng.uniform(4, cols - 5),
                y=self.rng.uniform(4, rows - 8),
                vx=self.rng.uniform(-1.8, 1.8),
                vy=self.rng.uniform(-1.2, 1.2),
                char=self.rng.choice(["*", ".", "+"]),
                color=self.rng.choice([WARM_AMBER, CREAM, DUSTY_ROSE, FADED_TEAL]),
                life=life,
                max_life=life,
                glow=0.85,
                sway_amp=2.4,
                sway_freq=self.rng.uniform(1.2, 2.8),
                phase=self.rng.uniform(0.0, math.tau),
            )
        )

    def spawn_heart_burst(self, cx: float, cy: float, count: int = 35) -> None:
        """Spawn a celebratory firework burst of ASCII hearts, stars, and confetti."""
        palette = [HOT_ROSE, DUSTY_ROSE, WARM_AMBER, FADED_TEAL, CREAM, LAVENDER_HAZE, MINT_GLOW]
        chars = ["*", "+", "@", "#", "o", ".", "~"]
        for _ in range(count):
            angle = self.rng.uniform(0.0, math.tau)
            speed = self.rng.uniform(6.0, 24.0)
            life = self.rng.uniform(1.4, 3.2)
            self.particles.append(
                Particle(
                    x=cx,
                    y=cy,
                    vx=math.cos(angle) * speed * 1.4,
                    vy=math.sin(angle) * speed * 0.85 - 4.0,
                    char=self.rng.choice(chars),
                    color=self.rng.choice(palette),
                    life=life,
                    max_life=life,
                    glow=0.85,
                    gravity=9.5,
                    sway_amp=1.2,
                    phase=self.rng.uniform(0.0, math.tau),
                )
            )

    def update(self, dt: float) -> None:
        """Advance all particle positions, velocities, homing targets, and lifetimes."""
        self.clock += dt
        alive: List[Particle] = []
        for p in self.particles:
            p.life -= dt
            if p.life <= 0.0:
                continue

            if p.target_x is not None and p.target_y is not None:
                dx = p.target_x - p.x
                dy = p.target_y - p.y
                p.x += dx * min(1.0, dt * 3.8)
                p.y += dy * min(1.0, dt * 3.8)
            else:
                p.vy += p.gravity * dt
                sway = math.sin(self.clock * p.sway_freq + p.phase) * p.sway_amp
                p.x += (p.vx + sway) * dt
                p.y += p.vy * dt

            alive.append(p)
        self.particles = alive

    def draw(
        self,
        renderer: AsciiRenderer,
        surface: Optional[pygame.Surface] = None,
    ) -> None:
        """Render particles onto the ASCII grid and optional pixel surface for Unicode."""
        for p in self.particles:
            ratio = clamp(p.life / max(0.001, p.max_life), 0.0, 1.0)
            fade = math.sin(ratio * math.pi) if ratio < 0.25 or ratio > 0.85 else 1.0
            fade = clamp(fade + 0.25, 0.0, 1.0)
            col = int(round(p.x))
            row = int(round(p.y))
            shaded = scale_color(p.color, fade)

            if p.unicode_label and surface is not None:
                px = int(p.x * renderer.cell_w)
                py = int(p.y * renderer.cell_h)
                renderer.draw_unicode_overlay(
                    surface, px, py, p.unicode_label, shaded, alpha=int(255 * fade)
                )
            else:
                renderer.set_cell(col, row, p.char, shaded, glow=p.glow * fade)
