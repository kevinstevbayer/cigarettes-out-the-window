"""Typewriter narration sequencer, blinking terminal cursor, and script timing."""

from typing import List, Tuple

import config
from engine.palette import CREAM, DUSTY_ROSE, FADED_TEAL, RGB, WARM_AMBER
from engine.renderer import AsciiRenderer
from story import NarrationCue


class TypewriterNarrator:
    """Sequences timed NarrationCues and renders a terminal typewriter box with cursor."""

    def __init__(self, cues: Tuple[NarrationCue, ...]) -> None:
        self.cues: Tuple[NarrationCue, ...] = cues
        self.elapsed: float = 0.0
        self.cursor_timer: float = 0.0
        self.cursor_visible: bool = True

    def reset(self) -> None:
        """Restart the narration timeline from 0.0s."""
        self.elapsed = 0.0
        self.cursor_timer = 0.0
        self.cursor_visible = True

    def update(self, dt: float) -> None:
        """Advance narration elapsed clock and blinking cursor timer."""
        self.elapsed += dt
        self.cursor_timer += dt
        if self.cursor_timer >= config.CURSOR_BLINK_INTERVAL:
            self.cursor_timer -= config.CURSOR_BLINK_INTERVAL
            self.cursor_visible = not self.cursor_visible

    def get_active_lines(self, max_visible: int = 2) -> List[Tuple[str, bool]]:
        """Return up to max_visible lines of text with (visible_substring, is_currently_typing)."""
        visible: List[Tuple[str, bool]] = []
        for cue in self.cues:
            if self.elapsed < cue.start_time:
                continue
            dt_since = self.elapsed - cue.start_time
            cps = config.TYPEWRITER_CHARS_PER_SEC * cue.speed_multiplier
            chars_shown = int(dt_since * cps)
            if chars_shown < len(cue.text):
                visible.append((cue.text[:chars_shown], True))
            else:
                visible.append((cue.text, False))
        return visible[-max_visible:]

    def draw_narration_panel(
        self,
        renderer: AsciiRenderer,
        prompt_prefix: str = "steve@love:~$ ",
        border_color: RGB = DUSTY_ROSE,
        text_color: RGB = CREAM,
    ) -> None:
        """Draw the bottom terminal narration box with typed lines and blinking cursor."""
        box_row = renderer.rows - 6
        box_h = 5
        box_col = 4
        box_w = renderer.cols - 8

        renderer.draw_box(
            box_col,
            box_row,
            box_w,
            box_h,
            color=border_color,
            title="stdout // narrator",
            fill_bg=(16, 12, 22),
            glow=0.25,
        )

        lines = self.get_active_lines(max_visible=2)
        if not lines:
            cursor_str = "█" if self.cursor_visible else " "
            renderer.draw_text(
                box_col + 3,
                box_row + 2,
                f"{prompt_prefix}{cursor_str}",
                FADED_TEAL,
                glow=0.4,
            )
            return

        for idx, (line_text, is_typing) in enumerate(lines):
            r = box_row + 1 + idx * 2
            prefix = prompt_prefix if idx == len(lines) - 1 else "              "
            renderer.draw_text(box_col + 3, r, prefix, FADED_TEAL, glow=0.3)
            text_start = box_col + 3 + len(prefix)
            renderer.draw_text(text_start, r, line_text, text_color, glow=0.35)

            if idx == len(lines) - 1:
                cursor_col = text_start + len(line_text)
                if is_typing or self.cursor_visible:
                    renderer.set_cell(
                        cursor_col,
                        r,
                        "█",
                        WARM_AMBER,
                        glow=0.75,
                    )
