"""Pure-Python 2D/3D Perlin noise and Fractal Brownian Motion (fBm) implementation."""

import math
from typing import List, Tuple


class PerlinNoise:
    """Deterministic, smooth gradient noise generator implemented from scratch."""

    _GRAD3: List[Tuple[int, int, int]] = [
        (1, 1, 0), (-1, 1, 0), (1, -1, 0), (-1, -1, 0),
        (1, 0, 1), (-1, 0, 1), (1, 0, -1), (-1, 0, -1),
        (0, 1, 1), (0, -1, 1), (0, 1, -1), (0, -1, -1),
    ]

    def __init__(self, seed: int = 1999) -> None:
        """Initialize the permutation table from a seed."""
        p = list(range(256))
        state = seed & 0xFFFFFFFF
        for i in range(255, 0, -1):
            state = (1664525 * state + 1013904223) & 0xFFFFFFFF
            j = state % (i + 1)
            p[i], p[j] = p[j], p[i]
        self.perm: List[int] = p + p

    @staticmethod
    def _fade(t: float) -> float:
        """Quintic fade curve: 6t^5 - 15t^4 + 10t^3."""
        return t * t * t * (t * (t * 6.0 - 15.0) + 10.0)

    @staticmethod
    def _lerp(t: float, a: float, b: float) -> float:
        return a + t * (b - a)

    def _grad2(self, hash_val: int, x: float, y: float) -> float:
        g = self._GRAD3[hash_val % 12]
        return g[0] * x + g[1] * y

    def _grad3(self, hash_val: int, x: float, y: float, z: float) -> float:
        g = self._GRAD3[hash_val % 12]
        return g[0] * x + g[1] * y + g[2] * z

    def noise2(self, x: float, y: float) -> float:
        """Compute 2D Perlin noise in approximately [-1.0, 1.0]."""
        xi = math.floor(x) & 255
        yi = math.floor(y) & 255
        xf = x - math.floor(x)
        yf = y - math.floor(y)

        u = self._fade(xf)
        v = self._fade(yf)

        p = self.perm
        aa = p[p[xi] + yi]
        ab = p[p[xi] + yi + 1]
        ba = p[p[xi + 1] + yi]
        bb = p[p[xi + 1] + yi + 1]

        x1 = self._lerp(u, self._grad2(aa, xf, yf), self._grad2(ba, xf - 1.0, yf))
        x2 = self._lerp(
            u, self._grad2(ab, xf, yf - 1.0), self._grad2(bb, xf - 1.0, yf - 1.0)
        )
        return self._lerp(v, x1, x2)

    def noise3(self, x: float, y: float, z: float) -> float:
        """Compute 3D Perlin noise in approximately [-1.0, 1.0]."""
        xi = math.floor(x) & 255
        yi = math.floor(y) & 255
        zi = math.floor(z) & 255

        xf = x - math.floor(x)
        yf = y - math.floor(y)
        zf = z - math.floor(z)

        u = self._fade(xf)
        v = self._fade(yf)
        w = self._fade(zf)

        p = self.perm
        a = p[xi] + yi
        aa = p[a] + zi
        ab = p[a + 1] + zi
        b = p[xi + 1] + yi
        ba = p[b] + zi
        bb = p[b + 1] + zi

        x1 = self._lerp(
            u,
            self._grad3(p[aa], xf, yf, zf),
            self._grad3(p[ba], xf - 1.0, yf, zf),
        )
        x2 = self._lerp(
            u,
            self._grad3(p[ab], xf, yf - 1.0, zf),
            self._grad3(p[bb], xf - 1.0, yf - 1.0, zf),
        )
        y1 = self._lerp(v, x1, x2)

        x3 = self._lerp(
            u,
            self._grad3(p[aa + 1], xf, yf, zf - 1.0),
            self._grad3(p[ba + 1], xf - 1.0, yf, zf - 1.0),
        )
        x4 = self._lerp(
            u,
            self._grad3(p[ab + 1], xf, yf - 1.0, zf - 1.0),
            self._grad3(p[bb + 1], xf - 1.0, yf - 1.0, zf - 1.0),
        )
        y2 = self._lerp(v, x3, x4)

        return self._lerp(w, y1, y2)

    def fbm2(
        self,
        x: float,
        y: float,
        octaves: int = 3,
        lacunarity: float = 2.0,
        gain: float = 0.5,
    ) -> float:
        """Compute multi-octave 2D Fractal Brownian Motion normalized to [0.0, 1.0]."""
        total = 0.0
        frequency = 1.0
        amplitude = 1.0
        max_amp = 0.0
        for _ in range(octaves):
            total += self.noise2(x * frequency, y * frequency) * amplitude
            max_amp += amplitude
            amplitude *= gain
            frequency *= lacunarity
        norm = (total / max_amp) * 0.5 + 0.5
        return max(0.0, min(1.0, norm))


# Shared global noise instance for fast access across assets and shaders
GLOBAL_NOISE = PerlinNoise(seed=2026)
