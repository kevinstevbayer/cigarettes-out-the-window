"""Sun-faded 70s VHS and lo-fi bedroom-pop color palettes inspired by TV Girl."""

from typing import Tuple
from engine.easing import clamp, lerp_color

RGB = Tuple[int, int, int]

# Base Backgrounds (Warm near-blacks and CRT phosphor shadows)
BG_DEEP: RGB = (13, 10, 16)
BG_TAPE: RGB = (22, 16, 26)
BG_TERMINAL: RGB = (16, 14, 20)

# Greyscale / Monochrome (Chapter 1 "Before You")
MONO_DARK: RGB = (38, 40, 46)
MONO_MID: RGB = (92, 96, 108)
MONO_LIGHT: RGB = (165, 170, 182)
MONO_WHITE: RGB = (220, 224, 232)

# Signature TV Girl Pastel / Sun-Faded VHS Tones
DUSTY_ROSE: RGB = (232, 110, 148)
HOT_ROSE: RGB = (255, 82, 138)
FADED_TEAL: RGB = (92, 186, 196)
DEEP_TEAL: RGB = (44, 108, 128)
SUNSET_ORANGE: RGB = (244, 152, 98)
WARM_AMBER: RGB = (250, 198, 112)
CREAM: RGB = (248, 236, 216)
SEPIA_SHADOW: RGB = (88, 62, 74)
LAVENDER_HAZE: RGB = (182, 138, 212)
MINT_GLOW: RGB = (134, 222, 188)
ERROR_CORAL: RGB = (242, 94, 94)

# Iris & Eye Shaders
IRIS_OUTER: RGB = (74, 48, 82)
IRIS_MID: RGB = (168, 98, 134)
IRIS_GOLD: RGB = (246, 192, 124)
CATCHLIGHT_WHITE: RGB = (255, 250, 244)


def scale_color(color: RGB, factor: float) -> RGB:
    """Multiply an RGB color by a brightness factor and clamp to valid byte range."""
    return (
        int(clamp(color[0] * factor, 0.0, 255.0)),
        int(clamp(color[1] * factor, 0.0, 255.0)),
        int(clamp(color[2] * factor, 0.0, 255.0)),
    )


def desaturate(color: RGB, amount: float) -> RGB:
    """Desaturate an RGB tuple toward its perceived luminance greyscale."""
    lum = int(0.299 * color[0] + 0.587 * color[1] + 0.114 * color[2])
    grey: RGB = (lum, lum, lum)
    return lerp_color(color, grey, clamp(amount, 0.0, 1.0))


def warm_gradient(lum: float) -> RGB:
    """Map luminance [0, 1] through a sepia -> dusty rose -> sunset -> cream gradient."""
    v = clamp(lum, 0.0, 1.0)
    if v < 0.35:
        return lerp_color(SEPIA_SHADOW, DUSTY_ROSE, v / 0.35)
    if v < 0.70:
        return lerp_color(DUSTY_ROSE, SUNSET_ORANGE, (v - 0.35) / 0.35)
    return lerp_color(SUNSET_ORANGE, CREAM, (v - 0.70) / 0.30)


def tv_girl_gradient(lum: float) -> RGB:
    """Map luminance [0, 1] across the iconic cyan/teal and pink/rose contrast."""
    v = clamp(lum, 0.0, 1.0)
    if v < 0.4:
        return lerp_color(DEEP_TEAL, FADED_TEAL, v / 0.4)
    if v < 0.75:
        return lerp_color(FADED_TEAL, DUSTY_ROSE, (v - 0.4) / 0.35)
    return lerp_color(DUSTY_ROSE, CREAM, (v - 0.75) / 0.25)
