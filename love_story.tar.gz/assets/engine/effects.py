"""Post-processing CRT scanlines, film grain, vignette, VHS tracking glitch, and bloom."""

import math
import random
from typing import List, Tuple
import pygame

import config
from engine.easing import clamp
from engine.palette import DUSTY_ROSE, FADED_TEAL, WARM_AMBER


class PostProcessor:
    """Applies sun-faded 70s VHS and CRT monitor post-processing effects to a frame."""

    def __init__(self, width: int, height: int) -> None:
        self.width: int = width
        self.height: int = height
        self.rng: random.Random = random.Random(1975)

        self.scanline_surface: pygame.Surface = self._build_scanlines()
        self.vignette_surface: pygame.Surface = self._build_vignette()
        self.grain_frames: List[pygame.Surface] = [
            self._build_grain_frame(i) for i in range(6)
        ]
        self.grain_idx: int = 0
        self.grain_timer: float = 0.0

        # VHS tracking glitch state
        self.glitch_cooldown: float = self.rng.uniform(
            config.VHS_GLITCH_INTERVAL_MIN, config.VHS_GLITCH_INTERVAL_MAX
        )
        self.glitch_timer: float = 0.0
        self.forced_glitch_intensity: float = 0.0

    def _build_scanlines(self) -> pygame.Surface:
        """Pre-render horizontal CRT scanlines."""
        surf = pygame.Surface((self.width, self.height), pygame.SRCALPHA)
        alpha = config.SCANLINE_ALPHA
        for y in range(0, self.height, 2):
            pygame.draw.line(surf, (6, 4, 10, alpha), (0, y), (self.width, y), 1)
        return surf

    def _build_vignette(self) -> pygame.Surface:
        """Pre-render a soft radial darkening vignette around screen edges."""
        surf = pygame.Surface((self.width, self.height), pygame.SRCALPHA)
        cx = self.width / 2.0
        cy = self.height / 2.0
        max_dist = math.hypot(cx, cy)

        # Draw concentric rectangular bands for fast startup without per-pixel loops
        steps = 28
        for i in range(steps):
            frac = i / float(steps - 1)
            if frac < 0.45:
                continue
            norm = (frac - 0.45) / 0.55
            alpha = int(clamp(pow(norm, 1.9) * 195 * config.VIGNETTE_STRENGTH, 0, 210))
            inset_x = int((1.0 - frac) * cx)
            inset_y = int((1.0 - frac) * cy)
            rect = pygame.Rect(
                inset_x,
                inset_y,
                self.width - 2 * inset_x,
                self.height - 2 * inset_y,
            )
            thickness = max(4, int(max_dist / steps))
            pygame.draw.rect(surf, (8, 5, 12, alpha), rect, width=thickness)
        return surf

    def _build_grain_frame(self, seed_offset: int) -> pygame.Surface:
        """Pre-bake a translucent analog film grain overlay surface."""
        surf = pygame.Surface((self.width, self.height), pygame.SRCALPHA)
        local_rng = random.Random(9000 + seed_offset)
        dots = config.GRAIN_DENSITY * 12
        for _ in range(dots):
            x = local_rng.randrange(0, self.width, 2)
            y = local_rng.randrange(0, self.height, 2)
            tone = local_rng.choice([WARM_AMBER, DUSTY_ROSE, FADED_TEAL, (220, 210, 200)])
            a = local_rng.randint(10, config.GRAIN_ALPHA * 2)
            surf.fill((*tone, a), (x, y, 2, 2))
        return surf

    def trigger_glitch(self, duration: float = 0.35, intensity: float = 1.0) -> None:
        """Manually trigger a VHS tracking glitch (e.g., on chapter changes or errors)."""
        self.glitch_timer = max(self.glitch_timer, duration)
        self.forced_glitch_intensity = max(self.forced_glitch_intensity, intensity)

    def update(self, dt: float) -> None:
        """Advance film grain cycling and VHS tracking glitch timers."""
        self.grain_timer += dt
        if self.grain_timer >= 0.045:
            self.grain_timer = 0.0
            self.grain_idx = (self.grain_idx + 1) % len(self.grain_frames)

        if self.glitch_timer > 0.0:
            self.glitch_timer = max(0.0, self.glitch_timer - dt)
            if self.glitch_timer == 0.0:
                self.forced_glitch_intensity = 0.0
        else:
            self.glitch_cooldown -= dt
            if self.glitch_cooldown <= 0.0:
                self.glitch_timer = config.VHS_GLITCH_DURATION
                self.forced_glitch_intensity = 0.75
                self.glitch_cooldown = self.rng.uniform(
                    config.VHS_GLITCH_INTERVAL_MIN, config.VHS_GLITCH_INTERVAL_MAX
                )

    def apply(self, surface: pygame.Surface) -> None:
        """Apply VHS tracking glitch, chromatic fringe, grain, scanlines, and vignette."""
        if config.ENABLE_VHS_GLITCH and self.glitch_timer > 0.0:
            self._apply_vhs_glitch(surface)

        if config.ENABLE_FILM_GRAIN:
            surface.blit(self.grain_frames[self.grain_idx], (0, 0))

        if config.ENABLE_SCANLINES:
            surface.blit(self.scanline_surface, (0, 0))

        if config.ENABLE_VIGNETTE:
            surface.blit(self.vignette_surface, (0, 0))

    def _apply_vhs_glitch(self, surface: pygame.Surface) -> None:
        """Slice horizontal bands and apply analog tracking snow and chromatic shift."""
        intensity = max(0.4, self.forced_glitch_intensity)
        num_slices = self.rng.randint(2, int(4 + 4 * intensity))
        for _ in range(num_slices):
            band_y = self.rng.randint(0, max(1, self.height - 32))
            band_h = self.rng.randint(8, 28)
            shift_x = int(self.rng.choice([-1, 1]) * self.rng.randint(4, int(18 * intensity)))
            rect = pygame.Rect(0, band_y, self.width, min(band_h, self.height - band_y))
            sub = surface.subsurface(rect).copy()
            surface.blit(sub, (shift_x, band_y))

            if config.ENABLE_CHROMATIC_OFFSET:
                # Pre-multiplied (alpha ~14%) so the additive blend is a subtle fringe, not a flash.
                base = DUSTY_ROSE if shift_x > 0 else FADED_TEAL
                tint = pygame.Surface((rect.width, rect.height))
                tint.fill((int(base[0] * 0.14), int(base[1] * 0.14), int(base[2] * 0.14)))
                surface.blit(tint, (0, band_y), special_flags=pygame.BLEND_RGB_ADD)

        # VHS horizontal tracking static line
        bar_y = int(((self.glitch_timer * 520.0) % self.height))
        pygame.draw.line(
            surface,
            (240, 225, 210),
            (0, bar_y),
            (self.width, bar_y),
            1,
        )
