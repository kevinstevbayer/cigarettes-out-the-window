"""Cell-grid ASCII renderer with luminance ramp shading, glyph caching, and bloom halos."""

from pathlib import Path
from typing import Dict, List, Optional, Tuple
import pygame
import pygame.freetype

import config
from engine.easing import clamp, lerp_color
from engine.palette import BG_DEEP, RGB, scale_color

# Bundled fonts live in <project>/fonts so the film looks identical on every machine
# (and so Tamil / Hindi / Arabic / Thai etc. render even if the OS lacks those fonts).
FONT_DIR: Path = Path(__file__).resolve().parent.parent / "fonts"
BUNDLED_MONO: str = "DejaVuSansMono.ttf"
BUNDLED_MONO_BOLD: str = "DejaVuSansMono-Bold.ttf"
BUNDLED_FALLBACKS: Tuple[str, ...] = (
    "NotoSansTamil-Regular.ttf",
    "NotoSansDevanagari-Regular.ttf",
    "NotoSansBengali-Regular.ttf",
    "NotoSansMalayalam-Regular.ttf",
    "NotoSansTelugu-Regular.ttf",
    "NotoSansKannada-Regular.ttf",
    "NotoSansArabic-Regular.ttf",
    "NotoSansHebrew-Regular.ttf",
    "NotoSansThai-Regular.ttf",
    "DejaVuSans.ttf",
)
# Extra system fonts worth trying for CJK scripts (Japanese / Korean / Chinese).
SYSTEM_CJK_NAMES: Tuple[str, ...] = (
    "Noto Sans CJK JP", "Noto Sans Mono CJK JP", "Noto Sans CJK SC", "Noto Sans CJK KR",
    "Yu Gothic", "Meiryo", "Malgun Gothic", "Microsoft YaHei", "Microsoft JhengHei",
    "SimHei", "PingFang SC", "Hiragino Sans", "Apple SD Gothic Neo", "Arial Unicode MS",
    "Segoe UI Symbol", "Segoe UI",
)
FONT_SIZE: int = 15


class AsciiRenderer:
    """Manages a 2D character cell grid and renders it with per-cell color and glow."""

    def __init__(self) -> None:
        self.cols: int = config.GRID_COLS
        self.rows: int = config.GRID_ROWS
        self.cell_w: int = config.CELL_WIDTH
        self.cell_h: int = config.CELL_HEIGHT
        self.width: int = config.LOGICAL_WIDTH
        self.height: int = config.LOGICAL_HEIGHT

        self.font_size: int = FONT_SIZE
        # pygame.font.metrics() reports placeholder metrics for missing glyphs, so glyph
        # coverage is checked through pygame.freetype (which correctly returns None).
        self._ft_map: Dict[int, pygame.freetype.Font] = {}
        self.font: pygame.font.Font = self._load_font(
            config.FONT_STACK, size=FONT_SIZE, bold=False
        )
        self.bold_font: pygame.font.Font = self._load_font(
            config.FONT_STACK, size=FONT_SIZE, bold=True
        )
        self.title_font: pygame.font.Font = self._load_font(
            config.FONT_STACK, size=28, bold=True
        )
        # Lazily-built chain of fallback fonts + per-text pick cache (see _pick_font)
        self._fallback_chain: Optional[List[pygame.font.Font]] = None
        self._font_pick_cache: Dict[Tuple[str, bool], pygame.font.Font] = {}

        # Grid storage
        self.chars: List[List[str]] = [
            [" " for _ in range(self.cols)] for _ in range(self.rows)
        ]
        self.colors: List[List[RGB]] = [
            [(255, 255, 255) for _ in range(self.cols)] for _ in range(self.rows)
        ]
        self.bg_colors: List[List[Optional[RGB]]] = [
            [None for _ in range(self.cols)] for _ in range(self.rows)
        ]
        self.glows: List[List[float]] = [
            [0.0 for _ in range(self.cols)] for _ in range(self.rows)
        ]

        # Glyph cache keyed by (char, quantized_rgb, bold)
        self._glyph_cache: Dict[Tuple[str, RGB, bool], pygame.Surface] = {}
        self._glow_circle_cache: Dict[Tuple[RGB, int], pygame.Surface] = {}

    def _make_font(self, path: str, size: int) -> pygame.font.Font:
        """Load a TTF/OTF file and register its freetype twin for coverage checks."""
        font = pygame.font.Font(path, size)
        try:
            self._ft_map[id(font)] = pygame.freetype.Font(path, size)
        except (pygame.error, OSError):
            pass
        return font

    def _load_font(
        self, font_names: Tuple[str, ...], size: int, bold: bool = False
    ) -> pygame.font.Font:
        """Resolve the best monospace font: bundled DejaVu Sans Mono first, then system fonts."""
        bundled = FONT_DIR / (BUNDLED_MONO_BOLD if bold else BUNDLED_MONO)
        if bundled.exists():
            try:
                return self._make_font(str(bundled), size)
            except (pygame.error, OSError):
                pass
        for name in font_names:
            matched = pygame.font.match_font(name, bold=bold)
            if matched:
                try:
                    return self._make_font(matched, size)
                except (pygame.error, OSError):
                    continue
        return pygame.font.SysFont("monospace", size, bold=bold)

    def _build_fallback_chain(self) -> List[pygame.font.Font]:
        """Assemble per-script fallback fonts: bundled Noto/DejaVu, then system CJK/Unicode fonts."""
        chain: List[pygame.font.Font] = []
        seen = set()

        def add(path: Optional[str]) -> None:
            if not path or path in seen:
                return
            seen.add(path)
            try:
                chain.append(self._make_font(path, self.font_size))
            except (pygame.error, OSError):
                pass

        for fname in BUNDLED_FALLBACKS:
            candidate = FONT_DIR / fname
            if candidate.exists():
                add(str(candidate))
        for name in SYSTEM_CJK_NAMES + tuple(config.UNICODE_FONT_STACK):
            add(pygame.font.match_font(name))
        # Last resort: any installed font that looks like a broad-coverage CJK/Unicode face
        for installed in pygame.font.get_fonts():
            if any(k in installed for k in ("cjk", "yahei", "gothic", "mincho", "unifont", "freesans")):
                add(pygame.font.match_font(installed))
        return chain

    def _pick_font(self, text: str, bold: bool = False) -> pygame.font.Font:
        """Return the first font whose glyph table covers every character of text."""
        key = (text, bold)
        cached = self._font_pick_cache.get(key)
        if cached is not None:
            return cached
        if self._fallback_chain is None:
            self._fallback_chain = self._build_fallback_chain()
        primary = self.bold_font if bold else self.font
        chosen = primary
        for candidate in [primary] + self._fallback_chain:
            if self._covers(candidate, text):
                chosen = candidate
                break
        if len(self._font_pick_cache) > 4000:
            self._font_pick_cache.clear()
        self._font_pick_cache[key] = chosen
        return chosen

    def _covers(self, font: pygame.font.Font, text: str) -> bool:
        """True if font has a real glyph for every (non-space) character in text."""
        ft = self._ft_map.get(id(font))
        probe = "".join(ch for ch in text if not ch.isspace())
        if not probe:
            return True
        if ft is None:
            return all(ord(ch) < 128 for ch in probe)
        try:
            metrics = ft.get_metrics(probe)
        except (pygame.error, OSError):
            return False
        return bool(metrics) and all(m is not None for m in metrics)

    def _render_runs(self, text: str, color: RGB) -> pygame.Surface:
        """Render mixed-script text by splitting it into runs, each drawn with a font that covers it."""
        runs: List[Tuple[pygame.font.Font, str]] = []
        for ch in text:
            neutral = ch.isspace() or (ord(ch) < 128 and not ch.isalnum())
            if neutral and runs and self._covers(runs[-1][0], ch):
                font = runs[-1][0]
            else:
                font = self._pick_font(ch)
            if runs and runs[-1][0] is font:
                runs[-1] = (font, runs[-1][1] + ch)
            else:
                runs.append((font, ch))
        pieces = []
        for font, chunk in runs:
            try:
                pieces.append(font.render(chunk, True, color))
            except pygame.error:
                continue
        width = sum(p.get_width() for p in pieces) or 1
        height = max((p.get_height() for p in pieces), default=self.cell_h)
        out = pygame.Surface((width, height), pygame.SRCALPHA)
        x = 0
        for piece in pieces:
            out.blit(piece, (x, (height - piece.get_height()) // 2))
            x += piece.get_width()
        return out

    def unicode_text_width(self, text: str) -> int:
        """Pixel width of text as draw_unicode_overlay would render it."""
        font = self._pick_font(text)
        if self._covers(font, text):
            return font.size(text)[0]
        return self._render_runs(text, (255, 255, 255)).get_width()

    def warm_up_text(self, texts: List[str]) -> None:
        """Pre-resolve fonts for a list of strings so first draw has no hitch."""
        for t in texts:
            font = self._pick_font(t)
            if not self._covers(font, t):
                self._render_runs(t, (255, 255, 255))

    def clear(self, bg_color: Optional[RGB] = None) -> None:
        """Reset all cells in the ASCII grid for a new frame."""
        for r in range(self.rows):
            row_chars = self.chars[r]
            row_bg = self.bg_colors[r]
            row_glow = self.glows[r]
            for c in range(self.cols):
                row_chars[c] = " "
                row_bg[c] = bg_color
                row_glow[c] = 0.0

    def in_bounds(self, col: int, row: int) -> bool:
        """Return True if (col, row) lies inside the grid."""
        return 0 <= col < self.cols and 0 <= row < self.rows

    def set_cell(
        self,
        col: int,
        row: int,
        char: str,
        color: RGB,
        glow: float = 0.0,
        bg: Optional[RGB] = None,
    ) -> None:
        """Write a single character, color, and glow value into the grid."""
        if not self.in_bounds(col, row) or not char:
            return
        self.chars[row][col] = char[0]
        self.colors[row][col] = color
        if glow > self.glows[row][col]:
            self.glows[row][col] = clamp(glow, 0.0, 1.0)
        if bg is not None:
            self.bg_colors[row][col] = bg

    def set_luminance(
        self,
        col: int,
        row: int,
        luminance: float,
        color: RGB,
        glow: float = 0.0,
        ramp: str = config.LUMINANCE_RAMP,
    ) -> None:
        """Convert a normalized luminance [0, 1] into an ASCII ramp character."""
        if not self.in_bounds(col, row):
            return
        lum = clamp(luminance, 0.0, 1.0)
        if lum <= 0.02:
            return
        idx = int(lum * (len(ramp) - 1))
        ch = ramp[idx]
        if ch == " ":
            return
        shaded_color = scale_color(color, 0.35 + 0.65 * lum)
        auto_glow = max(glow, (lum - config.BLOOM_THRESHOLD) * 1.5 if lum > config.BLOOM_THRESHOLD else 0.0)
        self.set_cell(col, row, ch, shaded_color, glow=auto_glow)

    def draw_text(
        self,
        col: int,
        row: int,
        text: str,
        color: RGB,
        glow: float = 0.0,
        bg: Optional[RGB] = None,
    ) -> None:
        """Draw a horizontal string into the cell grid starting at (col, row)."""
        if row < 0 or row >= self.rows:
            return
        for i, ch in enumerate(text):
            c = col + i
            if c >= self.cols:
                break
            if c >= 0 and ch != " ":
                self.set_cell(c, row, ch, color, glow=glow, bg=bg)
            elif c >= 0 and bg is not None:
                self.bg_colors[row][c] = bg

    def draw_centered_text(
        self,
        row: int,
        text: str,
        color: RGB,
        glow: float = 0.0,
        bg: Optional[RGB] = None,
    ) -> None:
        """Draw a horizontally centered string on the given row."""
        start_col = (self.cols - len(text)) // 2
        self.draw_text(start_col, row, text, color, glow=glow, bg=bg)

    def draw_box(
        self,
        col: int,
        row: int,
        width: int,
        height: int,
        color: RGB,
        title: str = "",
        fill_bg: Optional[RGB] = None,
        glow: float = 0.0,
    ) -> None:
        """Draw an ASCII box with optional title and background fill."""
        if width < 2 or height < 2:
            return
        for r in range(row, row + height):
            for c in range(col, col + width):
                if not self.in_bounds(c, r):
                    continue
                if fill_bg is not None:
                    self.bg_colors[r][c] = fill_bg
                    self.chars[r][c] = " "
                if r in (row, row + height - 1) and c in (col, col + width - 1):
                    self.set_cell(c, r, "+", color, glow=glow, bg=fill_bg)
                elif r in (row, row + height - 1):
                    self.set_cell(c, r, "-", color, glow=glow, bg=fill_bg)
                elif c in (col, col + width - 1):
                    self.set_cell(c, r, "|", color, glow=glow, bg=fill_bg)
        if title:
            label = f"[ {title} ]"
            self.draw_text(col + 2, row, label[: max(0, width - 4)], color, glow=glow, bg=fill_bg)

    def _get_glyph(self, char: str, color: RGB, bold: bool = False) -> pygame.Surface:
        """Retrieve or render a quantized cached glyph surface."""
        q_color: RGB = (
            (color[0] >> 2) << 2,
            (color[1] >> 2) << 2,
            (color[2] >> 2) << 2,
        )
        key = (char, q_color, bold)
        surf = self._glyph_cache.get(key)
        if surf is None:
            if len(self._glyph_cache) > 12000:
                self._glyph_cache.clear()
            font_to_use = (
                self._pick_font(char, bold)
                if ord(char) > 127
                else (self.bold_font if bold else self.font)
            )
            try:
                surf = font_to_use.render(char, True, q_color)
            except pygame.error:
                surf = self.font.render("?", True, q_color)
            self._glyph_cache[key] = surf
        return surf

    def _get_glow_stamp(self, color: RGB, alpha_step: int) -> pygame.Surface:
        """Retrieve or build a soft radial bloom stamp (pre-multiplied for additive blending)."""
        q_color: RGB = (
            (color[0] >> 3) << 3,
            (color[1] >> 3) << 3,
            (color[2] >> 3) << 3,
        )
        key = (q_color, alpha_step)
        stamp = self._glow_circle_cache.get(key)
        if stamp is None:
            if len(self._glow_circle_cache) > 1024:
                self._glow_circle_cache.clear()
            radius = 14
            stamp = pygame.Surface((radius * 2, radius * 2))
            stamp.fill((0, 0, 0))
            strength = alpha_step / 255.0
            # Concentric rings, brightest at the centre, so the halo fades smoothly.
            for ring, falloff in ((radius, 0.18), (int(radius * 0.72), 0.34), (int(radius * 0.46), 0.6), (int(radius * 0.24), 1.0)):
                ring_color = (
                    int(q_color[0] * strength * falloff),
                    int(q_color[1] * strength * falloff),
                    int(q_color[2] * strength * falloff),
                )
                pygame.draw.circle(stamp, ring_color, (radius, radius), max(1, ring))
            self._glow_circle_cache[key] = stamp
        return stamp

    def render_to_surface(
        self, surface: pygame.Surface, base_bg: RGB = BG_DEEP
    ) -> None:
        """Blit the entire ASCII cell grid, cell backgrounds, and bloom onto surface."""
        surface.fill(base_bg)
        cw = self.cell_w
        ch = self.cell_h
        enable_bloom = config.ENABLE_BLOOM

        for r in range(self.rows):
            y = r * ch
            row_chars = self.chars[r]
            row_colors = self.colors[r]
            row_bgs = self.bg_colors[r]
            row_glows = self.glows[r]

            for c in range(self.cols):
                x = c * cw
                bg = row_bgs[c]
                if bg is not None:
                    surface.fill(bg, (x, y, cw, ch))

                char = row_chars[c]
                if char == " ":
                    continue

                color = row_colors[c]
                glow = row_glows[c]

                if enable_bloom and glow > 0.08:
                    alpha_step = int(clamp(glow * 55.0 * config.BLOOM_INTENSITY * 3.0, 6.0, 75.0))
                    stamp = self._get_glow_stamp(color, alpha_step)
                    surface.blit(
                        stamp,
                        (x + cw // 2 - 14, y + ch // 2 - 14),
                        special_flags=pygame.BLEND_RGB_ADD,
                    )

                glyph = self._get_glyph(char, color, bold=(glow > 0.45))
                surface.blit(glyph, (x, y))

    def draw_unicode_overlay(
        self,
        surface: pygame.Surface,
        x_px: int,
        y_px: int,
        text: str,
        color: RGB,
        alpha: int = 255,
    ) -> None:
        """Render rich multi-character Unicode strings directly onto the pixel surface."""
        if alpha <= 0 or not text:
            return
        try:
            font = self._pick_font(text)
            if self._covers(font, text):
                rendered = font.render(text, True, color)
            else:
                rendered = self._render_runs(text, color)
            if alpha < 255:
                rendered.set_alpha(alpha)
            surface.blit(rendered, (x_px, y_px))
        except pygame.error:
            pass
