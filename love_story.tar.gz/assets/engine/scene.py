"""Abstract base Scene class for all story chapters."""

import pygame
from engine.renderer import AsciiRenderer
from engine.text import TypewriterNarrator
from story import CHAPTERS_STORY, ChapterMeta


class Scene:
    """Base class defining the lifecycle of a story chapter."""

    def __init__(self, chapter_index: int) -> None:
        self.chapter_index: int = chapter_index
        self.meta: ChapterMeta = CHAPTERS_STORY[chapter_index]
        self.narrator: TypewriterNarrator = TypewriterNarrator(self.meta.cues)
        self.time: float = 0.0

    def enter(self) -> None:
        """Called when the scene becomes active. Resets timers and state."""
        self.time = 0.0
        self.narrator.reset()

    def exit(self) -> None:
        """Called when transitioning away from the scene."""

    def update(self, dt: float) -> None:
        """Advance chapter simulation and narrator by delta time dt (in seconds)."""
        self.time += dt
        self.narrator.update(dt)

    def handle_event(self, event: pygame.event.Event) -> None:
        """Handle chapter-specific keyboard or mouse events."""

    def draw(self, renderer: AsciiRenderer, surface: pygame.Surface) -> None:
        """Populate the AsciiRenderer grid and render to the pixel surface."""
        raise NotImplementedError
