"""Mathematical easing functions and interpolation utilities."""

import math
from typing import Tuple


def clamp(value: float, low: float = 0.0, high: float = 1.0) -> float:
    """Clamp a float between low and high."""
    return max(low, min(high, value))


def lerp(a: float, b: float, t: float) -> float:
    """Linearly interpolate between a and b by clamped factor t."""
    t_clamped = clamp(t, 0.0, 1.0)
    return a + (b - a) * t_clamped


def lerp_color(
    c1: Tuple[int, int, int], c2: Tuple[int, int, int], t: float
) -> Tuple[int, int, int]:
    """Linearly interpolate between two RGB color tuples."""
    tc = clamp(t, 0.0, 1.0)
    return (
        int(c1[0] + (c2[0] - c1[0]) * tc),
        int(c1[1] + (c2[1] - c1[1]) * tc),
        int(c1[2] + (c2[2] - c1[2]) * tc),
    )


def smoothstep(edge0: float, edge1: float, x: float) -> float:
    """Hermite interpolation between two edges."""
    if abs(edge1 - edge0) < 1e-9:
        return 0.0
    t = clamp((x - edge0) / (edge1 - edge0), 0.0, 1.0)
    return t * t * (3.0 - 2.0 * t)


def ease_in_quad(t: float) -> float:
    """Quadratic ease-in."""
    tc = clamp(t)
    return tc * tc


def ease_out_quad(t: float) -> float:
    """Quadratic ease-out."""
    tc = clamp(t)
    return 1.0 - (1.0 - tc) * (1.0 - tc)


def ease_in_out_cubic(t: float) -> float:
    """Cubic ease-in-out curve."""
    tc = clamp(t)
    if tc < 0.5:
        return 4.0 * tc * tc * tc
    return 1.0 - pow(-2.0 * tc + 2.0, 3) / 2.0


def ease_out_back(t: float) -> float:
    """Overshooting cubic ease-out for playful UI pops."""
    tc = clamp(t)
    c1 = 1.70158
    c3 = c1 + 1.0
    return 1.0 + c3 * pow(tc - 1.0, 3) + c1 * pow(tc - 1.0, 2)


def ease_in_out_sine(t: float) -> float:
    """Gentle sinusoidal ease-in-out."""
    tc = clamp(t)
    return -(math.cos(math.pi * tc) - 1.0) / 2.0


def pulse_heartbeat(t: float, bpm: float = 72.0) -> float:
    """Generate a realistic double-peak lub-dub heartbeat curve in [0.0, 1.0]."""
    period = 60.0 / max(1.0, bpm)
    phase = (t % period) / period
    # Primary systolic peak and secondary dicrotic notch peak
    lub = math.exp(-pow((phase - 0.18) / 0.055, 2.0))
    dub = 0.65 * math.exp(-pow((phase - 0.34) / 0.07, 2.0))
    return clamp(lub + dub, 0.0, 1.0)
