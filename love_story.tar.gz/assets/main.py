"""Entry point, window management, main loop, and keyboard/mouse input router."""

import sys
import asyncio
from typing import List
import pygame

import config
from ascii_assets.phrases import LOVE_PHRASES, display_form
from engine.effects import PostProcessor
from engine.renderer import AsciiRenderer
from engine.scene import Scene
from engine.scene_manager import SceneManager
from scenes.ch00_prologue import Ch00PrologueScene
from scenes.ch01_before_you import Ch01BeforeYouScene
from scenes.ch02_first_time import Ch02FirstTimeScene
from scenes.ch03_the_eyes import Ch03TheEyesScene
from scenes.ch04_falling import Ch04FallingScene
from scenes.ch05_every_language import Ch05EveryLanguageScene
from scenes.ch06_what_if import Ch06WhatIfScene
from scenes.ch07_us import Ch07UsScene
from scenes.ch08_the_question import Ch08TheQuestionScene
from scenes.ch09_epilogue import Ch09EpilogueScene


def build_scenes() -> List[Scene]:
    """Instantiate all 10 chapters of the ASCII short film in story order."""
    return [
        Ch00PrologueScene(),
        Ch01BeforeYouScene(),
        Ch02FirstTimeScene(),
        Ch03TheEyesScene(),
        Ch04FallingScene(),
        Ch05EveryLanguageScene(),
        Ch06WhatIfScene(),
        Ch07UsScene(),
        Ch08TheQuestionScene(),
        Ch09EpilogueScene(),
    ]


def translate_mouse_event(
    event: pygame.event.Event,
    window_size: tuple[int, int],
    logical_size: tuple[int, int],
) -> pygame.event.Event:
    """Map window mouse coordinates to logical render-surface coordinates on resize."""
    win_w, win_h = max(1, window_size[0]), max(1, window_size[1])
    log_w, log_h = logical_size
    if hasattr(event, "pos"):
        lx = int(event.pos[0] * (log_w / float(win_w)))
        ly = int(event.pos[1] * (log_h / float(win_h)))
        if event.type == pygame.MOUSEMOTION:
            return pygame.event.Event(
                pygame.MOUSEMOTION,
                {"pos": (lx, ly), "rel": event.rel, "buttons": event.buttons},
            )
        if event.type in (pygame.MOUSEBUTTONDOWN, pygame.MOUSEBUTTONUP):
            return pygame.event.Event(
                event.type, {"pos": (lx, ly), "button": event.button}
            )
    return event


async def main():
    """Initialize Pygame, run the 60fps delta-time narrative loop, and exit cleanly."""
    pygame.init()
    pygame.font.init()
    pygame.display.set_caption(config.WINDOW_TITLE)

    flags = pygame.RESIZABLE if config.ALLOW_RESIZE else 0
    screen = pygame.display.set_mode(
        (config.DEFAULT_WIDTH, config.DEFAULT_HEIGHT), flags
    )
    logical_canvas = pygame.Surface(
        (config.LOGICAL_WIDTH, config.LOGICAL_HEIGHT)
    ).convert()

    renderer = AsciiRenderer()
    renderer.warm_up_text([display_form(lang, native) for lang, native, _ in LOVE_PHRASES])
    post_processor = PostProcessor(config.LOGICAL_WIDTH, config.LOGICAL_HEIGHT)
    scenes = build_scenes()
    manager = SceneManager(scenes, renderer, post_processor)

    clock = pygame.time.Clock()
    fullscreen = False
    running = True

    while running:
        raw_dt = clock.tick(config.FPS) / 1000.0
        dt = min(raw_dt, 0.1)  # Guard against spiral of death on window drag

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.VIDEORESIZE and not fullscreen:
                w = max(640, event.w)
                h = max(360, event.h)
                screen = pygame.display.set_mode((w, h), pygame.RESIZABLE)
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False
                elif event.key == pygame.K_SPACE:
                    manager.paused = not manager.paused
                elif event.key == pygame.K_RIGHT:
                    manager.next_chapter()
                elif event.key == pygame.K_LEFT:
                    manager.prev_chapter()
                elif event.key == pygame.K_r:
                    manager.restart_current()
                elif event.key == pygame.K_F11:
                    fullscreen = not fullscreen
                    if fullscreen:
                        screen = pygame.display.set_mode(
                            (0, 0), pygame.FULLSCREEN
                        )
                    else:
                        screen = pygame.display.set_mode(
                            (config.DEFAULT_WIDTH, config.DEFAULT_HEIGHT),
                            pygame.RESIZABLE,
                        )
                else:
                    manager.handle_event(event)
            elif event.type in (
                pygame.MOUSEMOTION,
                pygame.MOUSEBUTTONDOWN,
                pygame.MOUSEBUTTONUP,
            ):
                mapped = translate_mouse_event(
                    event,
                    screen.get_size(),
                    (config.LOGICAL_WIDTH, config.LOGICAL_HEIGHT),
                )
                manager.handle_event(mapped)

        manager.update(dt)
        post_processor.update(dt)

        manager.draw(logical_canvas)
        post_processor.apply(logical_canvas)

        # Smoothly scale the fixed logical ASCII canvas to any current window dimensions
        win_size = screen.get_size()
        if win_size == (config.LOGICAL_WIDTH, config.LOGICAL_HEIGHT):
            screen.blit(logical_canvas, (0, 0))
        else:
            pygame.transform.smoothscale(logical_canvas, win_size, screen)

        pygame.display.flip()
        
        # Yield control back to the browser frame
        await asyncio.sleep(0)

    pygame.quit()
    sys.exit()


if __name__ == "__main__":
    asyncio.run(main())