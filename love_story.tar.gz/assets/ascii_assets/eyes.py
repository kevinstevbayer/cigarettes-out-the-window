"""Procedural ASCII eyes with Perlin-noise iris texture, catchlights, blinking, and gaze."""

import math
from typing import Tuple

from engine.easing import clamp, lerp_color, smoothstep
from engine.noise import GLOBAL_NOISE
from engine.palette import (
    CATCHLIGHT_WHITE,
    CREAM,
    DUSTY_ROSE,
    FADED_TEAL,
    IRIS_GOLD,
    IRIS_MID,
    IRIS_OUTER,
    RGB,
    SEPIA_SHADOW,
    WARM_AMBER,
)
from engine.renderer import AsciiRenderer


class ProceduralEyes:
    """Renders an expressive pair of shaded ASCII eyes with living iris fibers and starlight."""

    def __init__(self) -> None:
        self.gaze_x: float = 0.0
        self.gaze_y: float = 0.0
        self.blink_amount: float = 0.0  # 0.0 = wide open, 1.0 = closed
        self.happy_squint: float = 0.0  # 0.0 = normal, 1.0 = happy curved arc

    def update_natural_motion(
        self,
        t: float,
        look_at_viewer: bool = False,
        happy_close: bool = False,
    ) -> None:
        """Compute organic gaze drift and periodic soft blinks."""
        if happy_close:
            self.blink_amount = clamp(self.blink_amount + 0.06, 0.0, 0.88)
            self.happy_squint = 1.0
            self.gaze_x *= 0.9
            self.gaze_y *= 0.9
            return

        self.happy_squint = 0.0
        if look_at_viewer:
            self.gaze_x += (0.0 - self.gaze_x) * 0.08
            self.gaze_y += (0.0 - self.gaze_y) * 0.08
        else:
            target_gx = math.sin(t * 0.75) * 0.28 + math.cos(t * 1.9) * 0.12
            target_gy = math.cos(t * 0.6) * 0.14
            self.gaze_x += (target_gx - self.gaze_x) * 0.06
            self.gaze_y += (target_gy - self.gaze_y) * 0.06

        # Natural blink every ~4.6 seconds
        cycle = t % 4.6
        if 4.25 <= cycle <= 4.55:
            phase = (cycle - 4.25) / 0.30
            self.blink_amount = math.sin(phase * math.pi)
        else:
            self.blink_amount = 0.0

    def draw_pair(
        self,
        renderer: AsciiRenderer,
        center_col: int,
        center_row: int,
        t: float,
        scale: float = 1.0,
        alpha: float = 1.0,
        starlight_irises: bool = True,
    ) -> None:
        """Draw both left and right eyes symmetrically around (center_col, center_row)."""
        if alpha <= 0.02:
            return
        eye_sep = int(round(23 * scale))
        self._draw_single_eye(
            renderer,
            center_col - eye_sep,
            center_row,
            t,
            scale=scale,
            alpha=alpha,
            is_left=True,
            starlight=starlight_irises,
        )
        self._draw_single_eye(
            renderer,
            center_col + eye_sep,
            center_row,
            t,
            scale=scale,
            alpha=alpha,
            is_left=False,
            starlight=starlight_irises,
        )

        # Subtle nose bridge highlight between the eyes
        if alpha > 0.35:
            for dy in range(-1, 4):
                lum = 0.22 * alpha * (1.0 - abs(dy - 1) * 0.25)
                renderer.set_luminance(
                    center_col - 1,
                    center_row + dy,
                    lum,
                    SEPIA_SHADOW,
                    glow=0.1 * alpha,
                )

    def _draw_single_eye(
        self,
        renderer: AsciiRenderer,
        cx: int,
        cy: int,
        t: float,
        scale: float,
        alpha: float,
        is_left: bool,
        starlight: bool,
    ) -> None:
        """Render a single almond-shaped eye with eyelid crease, eyelashes, sclera, iris, and catchlight."""
        rx = max(6, int(round(17 * scale)))
        ry = max(3, int(round(7.5 * scale)))
        open_factor = max(0.06, 1.0 - self.blink_amount)

        # Draw soft eyebrow arch above eye
        brow_y_base = cy - ry - int(round(2.5 * scale))
        for dx in range(-rx - 2, rx + 3):
            nx = dx / float(rx + 2)
            tilt = nx * (0.18 if is_left else -0.18)
            arch = int(round((nx * nx * 2.2 + tilt) * scale))
            bx = cx + dx
            by = brow_y_base + arch
            brow_lum = (1.0 - abs(nx) * 0.65) * 0.65 * alpha
            renderer.set_luminance(bx, by, brow_lum, DUSTY_ROSE, glow=0.25 * alpha)

        # Almond eyelid upper and lower curves
        for dy in range(-ry - 2, ry + 3):
            for dx in range(-rx - 2, rx + 3):
                nx = dx / float(rx)
                if abs(nx) > 1.08:
                    continue

                # Almond envelope
                envelope = math.cos(nx * math.pi * 0.5)
                envelope = pow(max(0.0, envelope), 0.78)

                # Happy squint curves lower lid upward into an arc
                upper_lid = -ry * envelope * open_factor
                lower_lid = ry * (0.85 * envelope * open_factor)
                if self.happy_squint > 0.2:
                    curve = -ry * 0.45 * envelope
                    upper_lid = curve - 0.6
                    lower_lid = curve + 0.6

                # Eyelid lash line
                dist_upper = abs(dy - upper_lid)
                dist_lower = abs(dy - lower_lid)
                if dist_upper < 0.95 and abs(nx) <= 1.02:
                    lash_col = lerp_color(DUSTY_ROSE, CREAM, 0.55)
                    renderer.set_cell(
                        cx + dx,
                        cy + dy,
                        "=" if abs(nx) < 0.5 else ("/" if (nx < 0) == is_left else "\\"),
                        lash_col,
                        glow=0.6 * alpha,
                    )
                    continue

                if dist_lower < 0.75 and abs(nx) <= 0.96 and open_factor > 0.25:
                    renderer.set_luminance(
                        cx + dx, cy + dy, 0.48 * alpha, DUSTY_ROSE, glow=0.25 * alpha
                    )
                    continue

                # Check if inside open eye aperture
                if not (upper_lid < dy < lower_lid):
                    # Subtle warm eyelid shading just above upper lid
                    if upper_lid - 2.0 <= dy <= upper_lid and abs(nx) < 0.95:
                        renderer.set_luminance(
                            cx + dx, cy + dy, 0.22 * alpha, SEPIA_SHADOW
                        )
                    continue

                # Inside the eye aperture: compute iris & sclera coordinates
                iris_rx = rx * 0.52
                iris_ry = ry * 0.88
                ix = (dx - self.gaze_x * rx * 0.28) / max(1.0, iris_rx)
                iy = (dy - self.gaze_y * ry * 0.25) / max(1.0, iris_ry)
                iris_r = math.hypot(ix, iy)

                if iris_r > 1.0:
                    # Sclera (softly shaded off-white/teal at corners)
                    sclera_shade = clamp(1.0 - abs(nx) * 0.65 - abs(dy / float(ry)) * 0.35, 0.2, 0.75)
                    sclera_col = lerp_color(SEPIA_SHADOW, FADED_TEAL, sclera_shade * 0.5)
                    renderer.set_luminance(
                        cx + dx, cy + dy, sclera_shade * 0.55 * alpha, sclera_col
                    )
                    continue

                # Primary & secondary living catchlights (window reflection + starlight glint)
                cl1_dist = math.hypot(ix + 0.32, iy + 0.32)
                cl2_dist = math.hypot(ix - 0.35, iy - 0.28)
                if cl1_dist < 0.26:
                    renderer.set_cell(
                        cx + dx, cy + dy, "@", CATCHLIGHT_WHITE, glow=1.0 * alpha
                    )
                    continue
                if cl2_dist < 0.16:
                    renderer.set_cell(
                        cx + dx, cy + dy, "*", WARM_AMBER, glow=0.9 * alpha
                    )
                    continue

                # Deep pupil core
                if iris_r < 0.34:
                    renderer.set_cell(
                        cx + dx, cy + dy, ".", (28, 18, 34), glow=0.1
                    )
                    continue

                # Textured radial iris fibers using Perlin noise in polar coordinates
                theta = math.atan2(iy, ix)
                radial_noise = GLOBAL_NOISE.fbm2(
                    math.cos(theta) * 2.5 + t * 0.25,
                    math.sin(theta) * 2.5 + iris_r * 3.0,
                    octaves=3,
                )
                ring_glow = math.sin((iris_r - 0.34) / 0.66 * math.pi)
                lum = clamp((0.38 + 0.45 * radial_noise + 0.28 * ring_glow) * alpha, 0.15, 1.0)

                # Outer limbal ring is deep rose/plum; inner collarette is warm amber/gold
                iris_col: RGB = lerp_color(
                    IRIS_OUTER,
                    lerp_color(IRIS_MID, IRIS_GOLD, radial_noise),
                    ring_glow,
                )

                # Orbiting starlight constellations inside the iris
                if starlight:
                    star_angle = (theta + t * 0.55) % (math.pi / 2.0)
                    if abs(star_angle - 0.3) < 0.09 and 0.52 < iris_r < 0.82:
                        lum = 0.96 * alpha
                        iris_col = CREAM

                renderer.set_luminance(
                    cx + dx, cy + dy, lum, iris_col, glow=lum * 0.85
                )
