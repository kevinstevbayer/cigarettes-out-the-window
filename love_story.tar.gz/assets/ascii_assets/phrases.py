"""'I love you' in 34 languages (including Tamil, Hindi, Korean, Japanese, Arabic)."""

from typing import List, Tuple

# Tuple of (Language Name, Native Script / Unicode, Romanized / Code Comment)
LOVE_PHRASES: List[Tuple[str, str, str]] = [
    ("English", "I love you", "en_US"),
    ("Tamil", "நான் உன்னை காதலிக்கிறேன்", "Naan unnai kaadhalikkiren"),
    ("Hindi", "मैं तुमसे प्यार करता हूँ", "Main tumse pyaar karta hoon"),
    ("Korean", "사랑해", "Saranghae"),
    ("Japanese", "愛してる", "Aishiteru"),
    ("Arabic", "أحبك", "Uhibbuka"),
    ("French", "Je t'aime", "fr_FR"),
    ("Spanish", "Te quiero", "es_ES"),
    ("Italian", "Ti amo", "it_IT"),
    ("German", "Ich liebe dich", "de_DE"),
    ("Portuguese", "Eu te amo", "pt_BR"),
    ("Russian", "Я тебя люблю", "Ya tebya lyublyu"),
    ("Mandarin", "我爱你", "Wǒ ài nǐ"),
    ("Greek", "Σ' αγαπώ", "S'agapo"),
    ("Turkish", "Seni seviyorum", "tr_TR"),
    ("Dutch", "Ik hou van jou", "nl_NL"),
    ("Swedish", "Jag älskar dig", "sv_SE"),
    ("Polish", "Kocham cię", "pl_PL"),
    ("Vietnamese", "Anh yêu em", "vi_VN"),
    ("Thai", "ฉันรักคุณ", "Chan rak khun"),
    ("Filipino", "Mahal kita", "tl_PH"),
    ("Indonesian", "Aku cinta kamu", "id_ID"),
    ("Swahili", "Nakupenda", "sw_KE"),
    ("Hebrew", "אני אוהב אותך", "Ani ohev otach"),
    ("Persian", "دوستت دارم", "Doostat daram"),
    ("Bengali", "আমি তোমায় ভালোবাসি", "Ami tomay bhalobashi"),
    ("Malayalam", "ഞാൻ നിന്നെ സ്നേഹിക്കുന്നു", "Njan ninne snehikkunnu"),
    ("Telugu", "నేను నిన్ను ప్రేమిస్తున్నాను", "Nenu ninnu premisthunnanu"),
    ("Kannada", "ನಾನು ನಿನ್ನನ್ನು ಪ್ರೀತಿಸುತ್ತೇನೆ", "Naanu ninnannu preethisuvene"),
    ("Urdu", "میں تم سے محبت کرتا ہوں", "Main tumse mohabbat karta hoon"),
    ("Ukrainian", "Я тебе кохаю", "Ya tebe kokhayu"),
    ("Romanian", "Te iubesc", "ro_RO"),
    ("Hungarian", "Szeretlek", "hu_HU"),
    ("Czech", "Miluji tě", "cs_CZ"),
    ("Python", "while True: love(shana)", "O(forever)"),
    ("Binary", "01001100 01001111 01010110 01000101", "UTF-8"),
]


# pygame's text renderer lays glyphs out strictly left-to-right, so right-to-left scripts are
# stored here pre-shaped (Arabic joining forms) and in visual order. Generated offline with
# arabic-reshaper + python-bidi, so there is no runtime dependency on them.
RTL_VISUAL_FORMS: dict[str, str] = {
    "Arabic": "\ufeda\ufe92\ufea3\ufe83",
    "Hebrew": "\u05da\u05ea\u05d5\u05d0 \u05d1\u05d4\u05d5\u05d0 \u05d9\u05e0\u05d0",
    "Persian": "\ufee1\ufead\ufe8d\ufea9 \ufe96\ufe98\ufeb3\ufeed\ufea9",
    "Urdu": "\ufb9e\ufeee\ufba8 \ufe8e\ufe97\ufeae\ufb90 \ufe96\ufe92\ufea4\ufee3 \ufbaf\ufeb3 \ufee2\ufe97 \ufb9f\ufbff\ufee3",
}


def display_form(lang: str, native: str) -> str:
    """Return the string to actually draw for a phrase (visual order for RTL scripts)."""
    return RTL_VISUAL_FORMS.get(lang, native)
