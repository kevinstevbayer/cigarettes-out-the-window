"""Luminance-shaded procedural hero objects with Perlin-noise motion and glow."""

import math
from typing import Optional

from engine.easing import clamp, lerp_color, pulse_heartbeat
from engine.noise import GLOBAL_NOISE
from engine.palette import (
    CREAM,
    DUSTY_ROSE,
    FADED_TEAL,
    HOT_ROSE,
    MONO_DARK,
    MONO_LIGHT,
    MONO_MID,
    RGB,
    SEPIA_SHADOW,
    SUNSET_ORANGE,
    WARM_AMBER,
    tv_girl_gradient,
    warm_gradient,
)
from engine.renderer import AsciiRenderer
from story import HER_IG_HANDLE, PHONE_INCOMING_LINES, PHONE_OUTGOING_LINE


def draw_flame(
    renderer: AsciiRenderer,
    cx: int,
    cy: int,
    t: float,
    scale: float = 1.0,
    intensity: float = 1.0,
) -> None:
    """Render a flickering noise-driven ASCII candle/ember light source."""
    rx = int(9 * scale)
    ry = int(12 * scale)
    if rx < 2 or ry < 2:
        return

    for dy in range(-ry, ry + 1):
        for dx in range(-rx, rx + 1):
            nx = dx / float(rx)
            ny = dy / float(ry)
            # Sway grows toward the tip (top, ny < 0) so the flame licks side to side
            tip = max(0.0, -ny)
            sway = GLOBAL_NOISE.noise2(t * 1.5, ny * 1.3) * 0.45 * tip
            nxs = nx - sway
            # Teardrop: round belly at the bottom, pointed tip at the top
            width_mod = 1.0 - 0.8 * tip
            dist = math.hypot(nxs / max(0.12, width_mod), ny * 1.05)
            if dist > 1.12:
                continue

            n = GLOBAL_NOISE.fbm2(
                nx * 2.4 + math.sin(t * 1.7) * 0.3,
                ny * 2.4 + t * 2.8,
                octaves=3,
            )
            lum = (1.0 - dist) * 0.9 + (n - 0.35) * 0.4
            lum = clamp(lum * intensity, 0.0, 1.0)
            if lum > 0.06:
                color = warm_gradient(lum)
                renderer.set_luminance(
                    cx + dx, cy + dy, lum, color, glow=lum * 0.85
                )


def draw_vinyl_record(
    renderer: AsciiRenderer,
    cx: int,
    cy: int,
    radius: int,
    t: float,
    rpm_speed: float = 2.4,
) -> None:
    """Render a spinning ASCII vinyl record with specular sheen and TV Girl label."""
    aspect = 1.75  # Compensate for tall character cells
    rx = int(radius * aspect)
    ry = radius
    angle_offset = t * rpm_speed

    for dy in range(-ry, ry + 1):
        for dx in range(-rx, rx + 1):
            nx = dx / float(max(1, rx))
            ny = dy / float(max(1, ry))
            r = math.hypot(nx, ny)
            if r > 1.0:
                continue

            theta = math.atan2(ny, nx) + angle_offset
            # Center spindle hole
            if r < 0.08:
                renderer.set_cell(cx + dx, cy + dy, " ", (12, 10, 16))
                continue

            # Inner pastel record label
            if r < 0.34:
                split = math.sin(theta)
                label_col = DUSTY_ROSE if split >= 0 else FADED_TEAL
                lum = 0.65 + 0.25 * math.cos(theta * 2.0)
                renderer.set_luminance(cx + dx, cy + dy, lum, label_col, glow=0.45)
                continue

            # Outer vinyl grooves + rotating diagonal specular highlight
            groove = 0.5 + 0.5 * math.sin(r * 42.0)
            sheen = pow(max(0.0, math.cos((theta - angle_offset) * 2.0 - 0.8)), 6.0)
            noise_val = GLOBAL_NOISE.noise2(nx * 4.0 + t, ny * 4.0) * 0.1
            lum = clamp(0.30 + 0.20 * groove + 0.55 * sheen + noise_val, 0.12, 1.0)
            if r > 0.94:
                # Bright rim so the record reads as a disc, not a blob
                renderer.set_luminance(cx + dx, cy + dy, 0.78, DUSTY_ROSE, glow=0.35)
                continue
            color = lerp_color(
                SEPIA_SHADOW,
                WARM_AMBER if sheen > 0.35 else DUSTY_ROSE,
                sheen,
            )
            renderer.set_luminance(cx + dx, cy + dy, lum, color, glow=sheen * 0.6)


def draw_moon(
    renderer: AsciiRenderer,
    cx: int,
    cy: int,
    radius: int,
    t: float,
    crescent_offset: float = 0.38,
) -> None:
    """Render a glowing crescent/full moon with noise craters and soft halo."""
    aspect = 1.7
    rx = int(radius * aspect)
    ry = radius

    for dy in range(-ry - 2, ry + 3):
        for dx in range(-rx - 3, rx + 4):
            nx = dx / float(max(1, rx))
            ny = dy / float(max(1, ry))
            r = math.hypot(nx, ny)

            # Soft outer atmospheric halo
            if 1.0 < r < 1.35:
                halo = (1.35 - r) / 0.35
                renderer.set_luminance(
                    cx + dx, cy + dy, halo * 0.28, WARM_AMBER, glow=halo * 0.4
                )
                continue
            if r > 1.0:
                continue

            # Shadow sphere cut for crescent effect
            shadow_dist = math.hypot(nx - crescent_offset, ny + 0.15)
            if shadow_dist < 0.82:
                # Subtle earthshine on dark side of moon
                renderer.set_luminance(cx + dx, cy + dy, 0.12, FADED_TEAL, glow=0.05)
                continue

            crater = GLOBAL_NOISE.fbm2(nx * 3.0 + 1.2, ny * 3.0 + t * 0.05, octaves=2)
            limb = math.sqrt(max(0.0, 1.0 - r * r))
            lum = clamp(0.45 + 0.35 * limb + 0.25 * crater, 0.2, 1.0)
            color = lerp_color(WARM_AMBER, CREAM, lum)
            renderer.set_luminance(cx + dx, cy + dy, lum, color, glow=0.65)


def draw_heart_field(
    renderer: AsciiRenderer,
    cx: int,
    cy: int,
    scale: float,
    t: float,
    pulse_bpm: float = 74.0,
) -> None:
    """Render a luminance-shaded implicit heart curve with heartbeat pulse."""
    beat = 1.0 + 0.12 * pulse_heartbeat(t, bpm=pulse_bpm)
    eff_scale = scale * beat
    rx = int(18 * eff_scale)
    ry = int(11 * eff_scale)

    for dy in range(-ry, ry + 1):
        for dx in range(-rx, rx + 1):
            x = dx / (11.5 * eff_scale)
            y = -dy / (7.2 * eff_scale) + 0.18
            # Implicit heart equation: (x^2 + y^2 - 1)^3 - x^2 * y^3 <= 0
            val = pow(x * x + y * y - 1.0, 3.0) - (x * x) * pow(y, 3.0)
            if val <= 0.0:
                depth = clamp(1.0 - math.hypot(x * 0.75, (y - 0.2) * 0.85), 0.15, 1.0)
                shimmer = GLOBAL_NOISE.noise2(x * 3.0 + t * 1.5, y * 3.0 - t) * 0.18
                lum = clamp(depth + shimmer, 0.2, 1.0)
                col = lerp_color(DUSTY_ROSE, CREAM if lum > 0.82 else HOT_ROSE, lum)
                renderer.set_luminance(cx + dx, cy + dy, lum, col, glow=lum * 0.8)


def draw_phone_screen(
    renderer: AsciiRenderer,
    col: int,
    row: int,
    width: int,
    height: int,
    t: float,
    color_progress: float = 1.0,
    show_notification: bool = True,
) -> None:
    """Draw an ASCII smartphone frame with an Instagram UI, profile avatar, and typing indicator."""
    border_col = lerp_color(MONO_MID, DUSTY_ROSE, color_progress)
    bg_col = (18, 16, 24) if color_progress > 0.1 else (18, 18, 20)
    renderer.draw_box(
        col, row, width, height, border_col, title="IG // 01:42 AM", fill_bg=bg_col, glow=0.35 * color_progress
    )

    # Top speaker & battery bar
    renderer.draw_text(
        col + 2, row + 1, "5G  instagram.dm           [98%]", lerp_color(MONO_LIGHT, FADED_TEAL, color_progress)
    )
    renderer.draw_text(
        col + 1, row + 2, "-" * (width - 2), border_col
    )

    # Profile circle & username header
    avatar_col = lerp_color(MONO_LIGHT, WARM_AMBER, color_progress)
    renderer.draw_text(col + 3, row + 4, ".---.", avatar_col, glow=0.4 * color_progress)
    renderer.draw_text(col + 3, row + 5, f"| * * |  {HER_IG_HANDLE}", avatar_col, glow=0.5 * color_progress)
    renderer.draw_text(col + 3, row + 6, "'---'   Active now", lerp_color(MONO_MID, FADED_TEAL, color_progress))

    # Scrolling feed / DM bubbles
    scroll = int(t * 2.5) % 3
    if not show_notification:
        for i in range(3):
            ry = row + 8 + i * 4 - (scroll % 2)
            if row + 7 <= ry < row + height - 3:
                renderer.draw_box(col + 3, ry, width - 6, 3, MONO_DARK, fill_bg=(24, 24, 28))
                renderer.draw_text(col + 5, ry + 1, "post_id: #greyscale_feed", MONO_MID)
    else:
        # Notification banner & incoming messages
        ping_glow = 0.5 + 0.5 * math.sin(t * 6.0)
        notif_col = lerp_color(MONO_LIGHT, HOT_ROSE, color_progress)
        renderer.draw_box(
            col + 2,
            row + 8,
            width - 4,
            4,
            notif_col,
            title="NEW MESSAGE",
            fill_bg=(28, 18, 32),
            glow=0.6 * color_progress * ping_glow,
        )
        renderer.draw_text(
            col + 4, row + 9, PHONE_INCOMING_LINES[0], lerp_color(MONO_LIGHT, CREAM, color_progress)
        )
        renderer.draw_text(
            col + 4, row + 10, PHONE_INCOMING_LINES[1], lerp_color(MONO_LIGHT, CREAM, color_progress)
        )

        # Outgoing bubble
        renderer.draw_box(
            col + 6,
            row + 13,
            width - 8,
            3,
            lerp_color(MONO_MID, FADED_TEAL, color_progress),
            fill_bg=(16, 24, 32),
        )
        renderer.draw_text(
            col + 8, row + 14, PHONE_OUTGOING_LINE, lerp_color(MONO_LIGHT, CREAM, color_progress)
        )

        # Animated typing indicator ("shana is typing...")
        dots = "." * (1 + (int(t * 3.2) % 3))
        typing_str = f"shana is typing{dots:<3}"
        renderer.draw_text(
            col + 3,
            row + height - 3,
            typing_str,
            lerp_color(MONO_LIGHT, WARM_AMBER, color_progress),
            glow=0.55 * color_progress,
        )


def draw_coffee_cup(
    renderer: AsciiRenderer,
    col: int,
    row: int,
    t: float,
    warmth: float = 0.0,
) -> None:
    """Draw a desk mug with procedural noise-curling ASCII steam wisps."""
    cup_col = lerp_color(MONO_MID, WARM_AMBER, warmth)
    steam_col = lerp_color(MONO_LIGHT, DUSTY_ROSE, warmth)

    # Rising curling steam above mug
    for sy in range(1, 6):
        sway = int(round(math.sin(t * 2.6 + sy * 0.9) * 1.6))
        ch = "(" if (sy + int(t * 3)) % 2 == 0 else ")"
        renderer.set_cell(col + 3 + sway, row - sy, ch, steam_col, glow=0.25 * warmth)
        renderer.set_cell(col + 6 - sway, row - sy, ch, steam_col, glow=0.25 * warmth)

    mug_lines = [
        " .------. ",
        " |      |)",
        " | ☕   |'",
        " '------' ",
    ]
    for i, line in enumerate(mug_lines):
        renderer.draw_text(col, row + i, line, cup_col, glow=0.2 * warmth)


def apply_radial_color_wave(
    renderer: AsciiRenderer,
    origin_col: int,
    origin_row: int,
    radius: float,
    t: float,
) -> None:
    """Spread a shimmering wave of TV Girl rose/teal/amber across the grid."""
    for r in range(renderer.rows - 6):
        for c in range(renderer.cols):
            dx = (c - origin_col) * 0.55
            dy = r - origin_row
            dist = math.hypot(dx, dy)
            ring = abs(dist - radius)
            if ring < 2.8:
                lum = 1.0 - (ring / 2.8)
                color = tv_girl_gradient(( math.sin(dist * 0.3 - t * 3.0) + 1.0 ) * 0.5)
                if renderer.chars[r][c] == " ":
                    renderer.set_luminance(c, r, lum * 0.65, color, glow=lum * 0.75)
                else:
                    renderer.colors[r][c] = lerp_color(renderer.colors[r][c], color, lum)
                    renderer.glows[r][c] = max(renderer.glows[r][c], lum * 0.8)
