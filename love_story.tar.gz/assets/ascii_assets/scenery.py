"""Procedural ASCII environments: night city skyline, window pane, starfield, and desk."""

import math
import random
from typing import List, Tuple

from engine.easing import lerp_color
from engine.palette import (
    CREAM,
    DUSTY_ROSE,
    FADED_TEAL,
    MONO_DARK,
    MONO_LIGHT,
    MONO_MID,
    RGB,
    SEPIA_SHADOW,
    WARM_AMBER,
)
from engine.renderer import AsciiRenderer


class Starfield:
    """Multi-layer parallax starfield for night sky and falling chapters."""

    def __init__(self, cols: int, rows: int, count: int = 95, seed: int = 108) -> None:
        rng = random.Random(seed)
        self.cols: int = cols
        self.rows: int = rows
        # (x, y, speed_layer, phase, char, color_idx)
        self.stars: List[List[float]] = []
        self.chars: List[str] = []
        self.colors: List[RGB] = []

        palette = [CREAM, WARM_AMBER, DUSTY_ROSE, FADED_TEAL]
        for _ in range(count):
            layer = rng.choice([0.35, 0.7, 1.35])
            self.stars.append(
                [
                    rng.uniform(1, cols - 2),
                    rng.uniform(2, rows - 7),
                    layer,
                    rng.uniform(0.0, math.tau),
                ]
            )
            self.chars.append("." if layer < 0.5 else ("+" if layer < 1.0 else "*"))
            self.colors.append(rng.choice(palette))

    def update(self, dt: float, vx: float = 0.0, vy: float = 0.0) -> None:
        """Scroll stars by parallax velocity vector (vx, vy)."""
        max_y = self.rows - 6
        for s in self.stars:
            layer = s[2]
            s[0] = (s[0] + vx * layer * dt) % self.cols
            s[1] = 2.0 + ((s[1] - 2.0 + vy * layer * dt) % max(1.0, max_y - 2.0))

    def draw(self, renderer: AsciiRenderer, t: float, brightness: float = 1.0) -> None:
        """Render twinkling stars into the ASCII grid."""
        for i, (x, y, layer, phase) in enumerate(self.stars):
            twinkle = 0.45 + 0.55 * math.sin(t * (1.8 + layer) + phase)
            lum = twinkle * brightness
            if lum > 0.15:
                renderer.set_cell(
                    int(x),
                    int(y),
                    self.chars[i],
                    self.colors[i],
                    glow=lum * 0.5 * layer,
                )


def draw_night_city(
    renderer: AsciiRenderer,
    horizon_row: int,
    t: float,
    color_warmth: float = 0.0,
) -> None:
    """Draw a procedural ASCII city skyline with one warm lit bedroom window."""
    buildings: List[Tuple[int, int, int]] = [
        (3, 14, 15),
        (17, 11, 19),
        (28, 16, 13),
        (44, 15, 22),
        (59, 13, 16),
        (72, 18, 20),
        (90, 12, 14),
        (102, 15, 18),
    ]
    outline_col = lerp_color(MONO_DARK, SEPIA_SHADOW, color_warmth)
    lit_window_col = lerp_color(MONO_LIGHT, WARM_AMBER, 0.35 + 0.65 * color_warmth)

    for b_idx, (bx, bw, bh) in enumerate(buildings):
        top = horizon_row - bh
        renderer.draw_box(bx, top, bw, bh, outline_col, fill_bg=(14, 14, 19))

        # Windows grid inside building
        for wy in range(top + 2, horizon_row - 1, 3):
            for wx in range(bx + 2, bx + bw - 2, 4):
                # Keep almost all windows dark in Ch1 except one special lit window
                is_hero_window = b_idx == 3 and wy == top + 5 and wx == bx + 6
                if is_hero_window:
                    pulse = 0.75 + 0.25 * math.sin(t * 3.0)
                    renderer.draw_text(
                        wx, wy, "##", lit_window_col, glow=0.8 * pulse
                    )
                elif (b_idx * 7 + wx + wy) % 11 == 0:
                    dim_col = lerp_color(MONO_DARK, FADED_TEAL, color_warmth * 0.5)
                    renderer.draw_text(wx, wy, "..", dim_col)

    # Horizon street line
    renderer.draw_text(
        0, horizon_row, "=" * renderer.cols, lerp_color(MONO_MID, DUSTY_ROSE, color_warmth)
    )
