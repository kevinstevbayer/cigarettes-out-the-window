"""Two-figure ASCII character sprites with swaying and head-tilt animation frames."""

import math
from typing import List

from engine.palette import CREAM, DUSTY_ROSE, FADED_TEAL, WARM_AMBER
from engine.renderer import AsciiRenderer


def draw_couple_swaying(
    renderer: AsciiRenderer,
    center_col: int,
    base_row: int,
    t: float,
    holding_hands: bool = True,
) -> None:
    """Render Steve and Shana swaying gently together with floating music notes."""
    sway = int(round(math.sin(t * 2.2) * 1.0))
    bob = int(round(abs(math.cos(t * 2.2)) * 0.6))

    # Left figure (Steve - faded teal / cream)
    steve_lines: List[str] = [
        "  .---.  ",
        " ( o_o ) ",
        "  |   |  ",
        " /|   |\\ ",
        "  |   |  ",
        " /     \\ ",
    ]
    # Right figure (Shana - dusty rose / warm amber, slightly shorter with flowing hair)
    shana_lines: List[str] = [
        "  .~*~.  ",
        " ( *_* ) ",
        " /|   |\\ ",
        "  | ~ |  ",
        " /     \\ ",
    ]

    sx = center_col - 9 + sway
    sy = base_row - len(steve_lines) + bob
    for i, line in enumerate(steve_lines):
        col_tone = CREAM if i <= 1 else FADED_TEAL
        renderer.draw_text(sx, sy + i, line, col_tone, glow=0.45)

    hx = center_col + 1 + sway
    hy = base_row - len(shana_lines) + bob
    for i, line in enumerate(shana_lines):
        col_tone = WARM_AMBER if i == 0 else (CREAM if i == 1 else DUSTY_ROSE)
        renderer.draw_text(hx, hy + i, line, col_tone, glow=0.55)

    if holding_hands:
        renderer.set_cell(center_col + sway, base_row - 3 + bob, "♥", DUSTY_ROSE, glow=0.9)

    # Labels above heads
    renderer.draw_text(sx + 2, sy - 2, "steve", FADED_TEAL, glow=0.3)
    renderer.draw_text(hx + 2, hy - 2, "shana", DUSTY_ROSE, glow=0.4)
