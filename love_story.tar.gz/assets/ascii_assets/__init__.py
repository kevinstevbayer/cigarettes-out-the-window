"""Procedural ASCII hero objects, eyes, animated figures, scenery, and phrases."""
